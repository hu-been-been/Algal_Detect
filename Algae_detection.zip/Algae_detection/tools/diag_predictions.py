#!/usr/bin/env python3
"""Draw ground truth vs decoded predictions for a few images.

Usage:
    python tools/diag_predictions.py --ckpt runs_x/y/best.pt --ann <json> \
        --size 640 --out-dir logs/diag_vis [--indices 0,1,2]
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from pycocotools.coco import COCO

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.dataset import AlgaeDataset, letterbox, collate_fn
from src.evaluate import decode_image
from src.models.build import build_model, set_mag_ids


def load_ckpt(path: str, device):
    ck = torch.load(path, map_location="cpu", weights_only=False)
    cfg = ck.get("config", {})
    model = build_model(
        ckpt=cfg.get("ckpt"),
        num_classes=6,
        film=cfg.get("film", False),
        num_mags=cfg.get("num_mags", 3),
        film_hidden=cfg.get("film_hidden", 128),
        arch=cfg.get("arch", "dfine"),
        denoising=cfg.get("denoising", True),
        head_prior=None,
    )
    model.load_state_dict(ck["model"])
    model.to(device).eval()
    return model, cfg


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--ann", required=True)
    ap.add_argument("--img-root", default="algae")
    ap.add_argument("--size", type=int, default=640)
    ap.add_argument("--out-dir", default="logs/diag_vis")
    ap.add_argument("--indices", default="0,1,2,3")
    ap.add_argument("--score-thr", type=float, default=0.25)
    args = ap.parse_args()

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model, cfg = load_ckpt(args.ckpt, device)
    print("ckpt cfg:", {k: cfg.get(k) for k in ("size", "arch", "film", "denoising")})
    ds = AlgaeDataset(args.ann, args.img_root, size=args.size, train=False)
    coco = COCO(args.ann)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    idxs = [int(v) for v in args.indices.split(",") if v.strip() != ""]
    items = [ds[i] for i in idxs]
    batch = collate_fn(items)
    x = batch["pixel_values"].to(device)
    mag = batch["mag_ids"].to(device)
    with torch.no_grad():
        set_mag_ids(model, mag)
        out = model(pixel_values=x)

    for j, idx in enumerate(idxs):
        item = items[j]
        xyxy, scores, labels = decode_image(
            out.logits[j].float(), out.pred_boxes[j].float(), ds.size,
            item["letterbox"], item["orig_size"], score_thr=args.score_thr,
        )
        img_id = item["image_id"]
        path = Path(args.img_root) / coco.imgs[img_id]["file_name"]
        im = Image.open(path).convert("RGB")
        draw = ImageDraw.Draw(im)
        gt = coco.imgToAnns[img_id]
        for a in gt:
            x0, y0, w, h = a["bbox"]
            draw.rectangle([x0, y0, x0 + w, y0 + h], outline=(0, 255, 0), width=3)
        for (x0, y0, x1, y1), s, c in zip(xyxy, scores, labels):
            draw.rectangle([x0, y0, x1, y1], outline=(255, 0, 0), width=2)
            draw.text((x0, max(0, y0 - 10)), f"{int(c)}:{s:.2f}", fill=(255, 0, 0))
        dest = out_dir / f"img{img_id}_s{args.size}.png"
        im.save(dest)
        # nearest-GT IoU for each prediction (class-agnostic)
        gts = np.array([[a["bbox"][0], a["bbox"][1],
                         a["bbox"][0] + a["bbox"][2], a["bbox"][1] + a["bbox"][3]] for a in gt],
                       dtype=np.float32)
        if len(xyxy) and len(gts):
            best = []
            for b in xyxy:
                ix0, iy0 = np.maximum(b[0], gts[:, 0]), np.maximum(b[1], gts[:, 1])
                ix1, iy1 = np.minimum(b[2], gts[:, 2]), np.minimum(b[3], gts[:, 3])
                inter = np.clip(ix1 - ix0, 0, None) * np.clip(iy1 - iy0, 0, None)
                area_b = (b[2] - b[0]) * (b[3] - b[1])
                area_g = (gts[:, 2] - gts[:, 0]) * (gts[:, 3] - gts[:, 1])
                iou = inter / np.maximum(area_b + area_g - inter, 1e-6)
                best.append(iou.max())
            best = np.array(best)
            print(f"img {img_id} size={item['orig_size']} gt={len(gt)} pred={len(xyxy)} "
                  f"score>={args.score_thr} nearestIoU mean={best.mean():.3f} "
                  f"max/gt={best.max():.3f}")
        else:
            print(f"img {img_id} gt={len(gt)} pred={len(xyxy)}")
        print("  saved", dest)


if __name__ == "__main__":
    main()
