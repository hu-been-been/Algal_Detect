#!/usr/bin/env python3
"""Run a JSONL job manifest across a pool of GPUs.

Each line of the manifest is ``{"id": str, "cmd": [str, ...], "env": {...}}``.
The scheduler pins one job at a time to each GPU (or ``--max-per-gpu`` jobs),
streams stdout/stderr to ``logs/<id>.log`` and appends status records to
``logs/queue_status.jsonl``.

Example
-------
    python tools/run_queue.py --manifest runs/manifest.jsonl --gpus 0,1,2,3,4,5,6,7
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path


class JobLocks:
    """Advisory per-job locks so several queue processes can share a manifest."""

    def __init__(self, lock_dir: Path):
        self.dir = lock_dir
        self.dir.mkdir(parents=True, exist_ok=True)

    def acquire(self, job_id: str) -> int | None:
        path = self.dir / f"{job_id}.lock"
        fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o644)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            os.close(fd)
            return None
        os.ftruncate(fd, 0)
        os.write(fd, f"{os.getpid()} {time.time():.0f}\n".encode())
        return fd

    @staticmethod
    def release(fd: int) -> None:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def load_manifest(path: Path) -> list[dict]:
    jobs = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if line:
            jobs.append(json.loads(line))
    return jobs


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--gpus", default="0,1,2,3,4,5,6,7")
    ap.add_argument("--max-per-gpu", type=int, default=1)
    ap.add_argument("--log-dir", default="logs")
    ap.add_argument("--status", default="logs/queue_status.jsonl")
    ap.add_argument("--skip-existing", action="store_true", default=True)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--max-jobs", type=int, default=0)
    args = ap.parse_args()

    jobs = load_manifest(Path(args.manifest))
    if args.max_jobs:
        jobs = jobs[: args.max_jobs]
    gpus = [g.strip() for g in args.gpus.split(",") if g.strip()]
    log_dir = Path(args.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    status_path = Path(args.status)
    status_lock = threading.Lock()
    locks = JobLocks(log_dir / "locks")

    def finished(job_id: str) -> bool:
        """A job counts as done if any queue recorded a successful end for it."""
        job = next((j for j in jobs if j["id"] == job_id), None)
        if job and job.get("done_file") and Path(job["done_file"]).exists():
            return True
        if not status_path.exists():
            return False
        for line in status_path.read_text().splitlines():
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if rec.get("id") == job_id and rec.get("event") == "end" and rec.get("rc") == 0:
                return True
        return False

    jq: queue.Queue = queue.Queue()
    for j in jobs:
        jq.put(j)
    gq: queue.Queue = queue.Queue()
    for g in gpus:
        for _ in range(args.max_per_gpu):
            gq.put(g)

    def status(rec: dict) -> None:
        rec["ts"] = time.time()
        with status_lock:
            with status_path.open("a") as f:
                f.write(json.dumps(rec) + "\n")

    def worker() -> None:
        while True:
            try:
                gpu = gq.get_nowait()
            except queue.Empty:
                return
            try:
                job = jq.get_nowait()
            except queue.Empty:
                gq.put(gpu)
                return

            run_id = job["id"]
            if args.skip_existing and finished(run_id):
                print(f"[skip] {run_id}", flush=True)
                gq.put(gpu)
                continue

            log_path = log_dir / f"{run_id}.log"
            if args.dry_run:
                print(f"[dry] gpu={gpu} id={run_id} cmd={' '.join(job['cmd'])}")
                gq.put(gpu)
                continue

            lock_fd = locks.acquire(run_id)
            if lock_fd is None:
                # Another queue process is already running this job.
                gq.put(gpu)
                continue
            try:
                if args.skip_existing and finished(run_id):
                    print(f"[skip] {run_id}", flush=True)
                    continue
                env = os.environ.copy()
                env["CUDA_VISIBLE_DEVICES"] = gpu
                env.update({k: str(v) for k, v in job.get("env", {}).items()})
                status({"event": "start", "id": run_id, "gpu": gpu, "cmd": job["cmd"]})
                t0 = time.time()
                with log_path.open("a") as log:
                    log.write(f"\n===== START {time.strftime('%Y-%m-%d %H:%M:%S')} gpu={gpu} =====\n")
                    log.flush()
                    proc = subprocess.Popen(job["cmd"], env=env, stdout=log, stderr=subprocess.STDOUT)
                    rc = proc.wait()
                    log.write(f"\n===== END rc={rc} elapsed={time.time()-t0:.0f}s =====\n")
                status({"event": "end", "id": run_id, "gpu": gpu, "rc": rc, "elapsed_s": time.time() - t0})
                print(f"[{'ok' if rc == 0 else f'FAIL rc={rc}'}] {run_id} gpu={gpu} {time.time()-t0:.0f}s", flush=True)
            except Exception as exc:  # keep the worker alive and the GPU in rotation
                print(f"[error] {run_id} gpu={gpu}: {exc}", flush=True)
            finally:
                JobLocks.release(lock_fd)
                gq.put(gpu)

    threads = [threading.Thread(target=worker, daemon=True) for _ in range(len(gpus) * args.max_per_gpu)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    print("queue finished", flush=True)


if __name__ == "__main__":
    main()
