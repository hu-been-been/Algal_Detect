#!/usr/bin/env bash
# Run all inference-only evaluations for one trained model.
#
#   bash tools/eval_suite.sh <run_id> [baseline_run_id] [gpu]
#
# Produces results/eval/<run>_{full,tile}.json, results/counting_<run>.csv,
# and results/robustness/<run>.json (plus the baseline if given).
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-python}
RUN=${1:?usage: eval_suite.sh <run_id> [baseline_run_id] [gpu]}
BASE=${2:-}
GPU=${3:-0}
export CUDA_VISIBLE_DEVICES=$GPU
CKPT=runs/$RUN/best.pt
ANN=data/coco/annotations/instances_val.json
mkdir -p results/eval results/robustness

echo "[eval] $RUN full"
$PY src/evaluate.py --ckpt "$CKPT" --ann "$ANN" --out "results/eval/${RUN}_full.json" --device cuda:0

echo "[eval] $RUN tiled"
$PY src/evaluate.py --ckpt "$CKPT" --ann "$ANN" --tiling --out "results/eval/${RUN}_tile.json" --device cuda:0

echo "[counts] $RUN"
$PY src/counts_csv.py --preds "results/eval/${RUN}_tile_preds.json" --ann "$ANN" \
    --out "results/counting_${RUN}.csv" --thr 0.3

echo "[robustness] $RUN"
$PY src/robustness.py --ckpt "$CKPT" --name "$RUN" --tiling \
    --out "results/robustness/${RUN}.json" --device cuda:0

if [[ -n "$BASE" ]]; then
  echo "[robustness] baseline $BASE"
  $PY src/robustness.py --ckpt "runs/$BASE/best.pt" --name "$BASE" --tiling \
      --out "results/robustness/${BASE}.json" --device cuda:0
fi

echo "[done] $RUN"
