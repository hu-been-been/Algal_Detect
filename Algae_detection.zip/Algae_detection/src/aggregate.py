"""Collect all run metrics into tidy CSVs for tables and figures."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd


def block(m: dict, kind: str) -> dict:
    for key in (f"test_{kind}", f"val_{kind}"):
        if key in m:
            return m[key]
    return {}


def parse_run_id(rid: str) -> dict:
    out = {"run_id": rid}
    m = re.match(r"cd(\d)_", rid)
    if m:
        out["split"] = f"cd{m.group(1)}"
    elif rid.startswith("fold"):
        out["split"] = "fold" + re.match(r"fold(\d)", rid).group(1)
    elif rid.startswith("lc_"):
        out["split"] = "learning_curve"
    else:
        out["split"] = "main"
    m = re.search(r"_s(\d+)$", rid)
    out["seed"] = int(m.group(1)) if m else 0
    return out


def dfine_row(m: dict, rid: str) -> dict:
    cfg = m.get("config", {})
    full = block(m, "full")
    tile = block(m, "tile")
    row = {
        "run_id": rid,
        "family": cfg.get("arch", "dfine"),
        "size": cfg.get("size", None),
        "seed": cfg.get("seed", 0),
        "film": bool(cfg.get("film", False)),
        "nwd": bool(cfg.get("nwd", False)),
        "rfs": bool(cfg.get("rfs", False)),
        "copy_paste": float(cfg.get("copy_paste", 0.0) or 0.0),
        "tile_train": bool(cfg.get("tile_train", True)),
        "params": m.get("params"),
        "fps": m.get("fps_batch1"),
        "train_time_s": m.get("train_time_s"),
        "best_epoch": m.get("best_epoch"),
        "best_mAP": m.get("best_mAP"),
        "mAP_full": full.get("mAP"),
        "mAP50_full": full.get("mAP50"),
        "mAP75_full": full.get("mAP75"),
        "macro_full": full.get("macro_AP"),
        "tail2_full": full.get("tail_AP_2"),
        "tail4_full": full.get("tail_AP_4"),
        "mAP_tile": tile.get("mAP"),
        "mAP50_tile": tile.get("mAP50"),
        "macro_tile": tile.get("macro_AP"),
        "tail2_tile": tile.get("tail_AP_2"),
        "tail4_tile": tile.get("tail_AP_4"),
    }
    for g, v in (full.get("per_group") or {}).items():
        row[f"mAP_{g}_full"] = v.get("mAP")
        row[f"mAP50_{g}_full"] = v.get("mAP50")
    for g, v in (tile.get("per_group") or {}).items():
        row[f"mAP_{g}_tile"] = v.get("mAP")
    for c, v in (full.get("per_class_AP") or {}).items():
        row[f"AP_c{c}_full"] = v
    for c, v in (tile.get("per_class_AP") or {}).items():
        row[f"AP_c{c}_tile"] = v
    row.update(parse_run_id(rid))
    return row


def yolo_row(m: dict, rid: str) -> dict:
    row = {
        "run_id": rid,
        "family": Path(str(m.get("model", "yolo"))).stem,
        "size": m.get("size"),
        "seed": m.get("seed", 0),
        "film": False,
        "nwd": False,
        "rfs": False,
        "copy_paste": 0.0,
        "tile_train": False,
        "params": m.get("params"),
        "fps": None,
        "train_time_s": None,
        "best_epoch": None,
        "best_mAP": m.get("mAP"),
        "mAP_full": m.get("mAP"),
        "mAP50_full": m.get("mAP50"),
        "mAP75_full": m.get("mAP75"),
        "macro_full": float(np.mean(list(m.get("per_class_AP", {}).values()))) if m.get("per_class_AP") else None,
        "tail2_full": None,
        "tail4_full": None,
        "mAP_tile": None,
    }
    for c, v in (m.get("per_class_AP") or {}).items():
        row[f"AP_c{c}_full"] = v
    row.update(parse_run_id(rid))
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--runs-yolo", default="runs_yolo")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    rows = []
    for p in sorted(Path(args.runs).glob("*/metrics.json")):
        try:
            m = json.loads(p.read_text())
            rows.append(dfine_row(m, p.parent.name))
        except Exception as e:
            print(f"skip {p}: {e}")
    for p in sorted(Path(args.runs_yolo).glob("*/metrics.json")):
        try:
            m = json.loads(p.read_text())
            rows.append(yolo_row(m, p.parent.name))
        except Exception as e:
            print(f"skip {p}: {e}")

    df = pd.DataFrame(rows)
    if df.empty:
        print("no runs found")
        return
    df.to_csv(out / "all_runs.csv", index=False)
    print(f"all_runs: {len(df)} rows")

    def summarize(sub: pd.DataFrame, keys: list[str], metrics: list[str]) -> pd.DataFrame:
        agg = sub.groupby(keys)[metrics].agg(["mean", "std"])
        agg.columns = [f"{a}_{b}" for a, b in agg.columns]
        return agg.reset_index()

    # benchmark: one row per family × size
    bench = df[df["run_id"].str.startswith("bench")]
    if not bench.empty:
        cols = ["mAP_full", "mAP50_full", "macro_full", "tail2_full", "mAP_tile", "params", "fps", "train_time_s"]
        cols = [c for c in cols if c in bench]
        b = summarize(bench, ["family", "size"], cols)
        b.to_csv(out / "benchmark.csv", index=False)
        print(b.to_string(index=False))

    # module ablation: D-FINE at 1280 with standard tiling is the base row
    base = df[
        df["run_id"].str.startswith("bench")
        & (df["family"] == "dfine")
        & (df["size"] == 1280)
    ]
    mod = pd.concat([df[df["run_id"].str.startswith("mod_")], base])
    if not mod.empty:
        mod = mod.copy()
        mod["variant"] = np.where(mod["film"], "F", "") + np.where(mod["nwd"], "N", "") + np.where(mod["rfs"], "R", "") + np.where(mod["copy_paste"] > 0, "C", "")
        mod["variant"] = mod["variant"].replace("", "base")
        cols = ["mAP_full", "mAP50_full", "macro_full", "tail2_full", "tail4_full", "mAP_tile", "mAP50_tile"]
        cols = [c for c in cols if c in mod]
        b = summarize(mod, ["variant", "tile_train"], cols)
        b.to_csv(out / "modules.csv", index=False)
        print(b.to_string(index=False))

    # cross-domain
    cd = df[df["run_id"].str.startswith("cd")]
    if not cd.empty:
        cd = cd.copy()
        cd["cd"] = cd["run_id"].str.extract(r"(cd\d)")[0]
        cd["variant"] = np.where(cd["film"], "F", "") + np.where(cd["nwd"], "N", "") + np.where(cd["rfs"], "R", "") + np.where(cd["copy_paste"] > 0, "C", "")
        cd["variant"] = cd["variant"].replace("", "base")
        cols = ["mAP_full", "mAP50_full", "macro_full", "tail2_full", "mAP_tile"]
        cols = [c for c in cols if c in cd]
        b = summarize(cd, ["cd", "size", "variant"], cols)
        b.to_csv(out / "cross_domain.csv", index=False)
        print(b.to_string(index=False))

    # folds
    folds = df[df["run_id"].str.startswith("fold")]
    if not folds.empty:
        folds = folds.copy()
        folds["variant"] = np.where(
            folds["run_id"].str.contains(r"final|full", regex=True), "final", "base")
        cols = ["mAP_full", "mAP50_full", "macro_full", "tail2_full", "mAP_tile"]
        cols = [c for c in cols if c in folds]
        b = summarize(folds, ["variant"], cols)
        b.to_csv(out / "folds.csv", index=False)
        print(b.to_string(index=False))

    # learning curve
    lc = df[df["run_id"].str.startswith("lc_")]
    if not lc.empty:
        lc = lc.copy()
        lc["fraction"] = lc["run_id"].str.extract(r"lc_(\d+)_")[0].astype(float) / 100
        cols = ["mAP_full", "mAP50_full", "macro_full", "tail2_full"]
        cols = [c for c in cols if c in lc]
        b = summarize(lc, ["fraction"], cols)
        b.to_csv(out / "learning_curve.csv", index=False)
        print(b.to_string(index=False))

    print(f"wrote CSVs to {out}")


if __name__ == "__main__":
    main()
