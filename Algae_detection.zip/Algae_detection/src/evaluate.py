"""Evaluation: COCO AP, per-class/tail AP, counting and ecological metrics."""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import torch
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from torchvision.ops import nms

from src.data.dataset import CLASS_NAMES, AlgaeDataset, collate_fn
from src.models.build import build_model, set_mag_ids

TAIL_CLASSES_2 = (0, 5)  # Platymonas, Haematococcus
TAIL_CLASSES_4 = (0, 2, 3, 5)


# --------------------------------------------------------------------------- #
# prediction decoding
# --------------------------------------------------------------------------- #
def decode_image(
    logits: torch.Tensor,
    boxes: torch.Tensor,
    size: int,
    letterbox: tuple[float, int, int],
    orig_size: tuple[int, int],
    offset: tuple[int, int] = (0, 0),
    score_thr: float = 0.001,
    topk: int = 300,
    class_bias: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Decode one image's query outputs to original-image xyxy boxes.

    ``logits`` [Q,C], ``boxes`` [Q,4] normalised cxcywh on the letterboxed
    canvas of side ``size``.  ``offset`` is the tile origin in original pixels.
    ``class_bias`` [C] is added to the logits (logit adjustment for long tails).
    """
    if class_bias is not None:
        logits = logits + torch.as_tensor(class_bias, dtype=logits.dtype, device=logits.device)
    scores = logits.sigmoid()
    scores, labels = scores.max(dim=-1)          # both in query order
    k = min(topk, scores.numel())
    scores, idx = scores.topk(k)                 # now sorted by score
    labels = labels[idx]                         # keep labels aligned with the sort
    keep = scores >= score_thr
    scores, idx, labels = scores[keep], idx[keep], labels[keep]
    if scores.numel() == 0:
        return (
            np.zeros((0, 4), np.float32),
            np.zeros((0,), np.float32),
            np.zeros((0,), np.int64),
        )
    b = boxes[idx]
    scale, pad_x, pad_y = letterbox
    cx = (b[:, 0] * size - pad_x) / scale + offset[0]
    cy = (b[:, 1] * size - pad_y) / scale + offset[1]
    bw = b[:, 2] * size / scale
    bh = b[:, 3] * size / scale
    x1 = (cx - bw / 2).clamp(0, orig_size[0] - 1)
    y1 = (cy - bh / 2).clamp(0, orig_size[1] - 1)
    x2 = (cx + bw / 2).clamp(0, orig_size[0] - 1)
    y2 = (cy + bh / 2).clamp(0, orig_size[1] - 1)
    xyxy = torch.stack([x1, y1, x2, y2], dim=1).cpu().numpy()
    valid = (xyxy[:, 2] - xyxy[:, 0] > 1) & (xyxy[:, 3] - xyxy[:, 1] > 1)
    return xyxy[valid], scores.cpu().numpy()[valid], labels.cpu().numpy()[valid]


def results_from_arrays(
    image_id: int,
    xyxy: np.ndarray,
    scores: np.ndarray,
    labels: np.ndarray,
    nms_iou: float = 0.6,
    max_det: int = 300,
) -> list[dict]:
    if len(xyxy) == 0:
        return []
    keep_all = []
    for c in np.unique(labels):
        m = labels == c
        b = torch.from_numpy(xyxy[m])
        s = torch.from_numpy(scores[m])
        keep = nms(b, s, nms_iou)[:max_det]
        keep_all.append(np.where(m)[0][keep.numpy()])
    keep = np.concatenate(keep_all)
    out = []
    for i in keep:
        x1, y1, x2, y2 = xyxy[i].tolist()
        out.append(
            {
                "image_id": int(image_id),
                "category_id": int(labels[i]),
                "bbox": [float(x1), float(y1), float(x2 - x1), float(y2 - y1)],
                "score": float(scores[i]),
            }
        )
    return out


# --------------------------------------------------------------------------- #
# tiling
# --------------------------------------------------------------------------- #
def tile_grid(
    w: int,
    h: int,
    tile_size: int,
    overlap: float = 0.25,
    aspect: float | None = None,
) -> list[tuple[int, int, int, int]]:
    """Tile grid. With ``aspect`` the tiles are ``aspect:1`` rectangles.

    Wide strip images are only 608 px high, so square tiles are clamped to
    608x608 and cannot reproduce the 2:1 crop used during training.  An
    aspect of 2 keeps the tile at the training magnification instead.
    """
    if aspect:
        th = min(tile_size, h)
        tw = min(w, max(1, int(round(th * aspect))))
    else:
        tw = th = min(tile_size, w, h)
    sx = max(1, int(round(tw * (1 - overlap))))
    sy = max(1, int(round(th * (1 - overlap))))
    xs = list(range(0, max(w - tw, 0) + 1, sx))
    ys = list(range(0, max(h - th, 0) + 1, sy))
    if xs[-1] != w - tw:
        xs.append(w - tw)
    if ys[-1] != h - th:
        ys.append(h - th)
    return [(x, y, x + tw, y + th) for y in ys for x in xs]


def default_tile_size(w: int, h: int) -> int:
    if w / max(h, 1) > 2.2:
        return min(h, 800)
    if w * h > 1_500_000:
        return 800
    return max(w, h)


# --------------------------------------------------------------------------- #
# model inference over a dataset
# --------------------------------------------------------------------------- #
@torch.no_grad()
def predict_dataset(
    model: torch.nn.Module,
    dataset: AlgaeDataset,
    device: torch.device,
    batch_size: int = 8,
    score_thr: float = 0.001,
    topk: int = 300,
    tiling: bool = False,
    tile_size: int | None = None,
    overlap: float = 0.25,
    tile_aspect: float | None = None,
    nms_iou: float = 0.6,
    max_det: int = 300,
    amp_dtype: torch.dtype | None = torch.bfloat16,
    class_bias: np.ndarray | None = None,
) -> tuple[list[dict], dict[str, Any]]:
    """Run inference and return COCO-format detections plus timing info."""
    from PIL import Image

    model.eval()
    results: list[dict] = []
    n_images = 0
    n_tiles = 0
    t_start = time.time()

    for start in range(0, len(dataset), batch_size):
        items = [dataset[i] for i in range(start, min(start + batch_size, len(dataset)))]
        n_images += len(items)

        if not tiling:
            batch = collate_fn(items)
            x = batch["pixel_values"].to(device, non_blocking=True)
            mag = batch["mag_ids"].to(device)
            with torch.autocast("cuda", dtype=amp_dtype, enabled=amp_dtype is not None and device.type == "cuda"):
                set_mag_ids(model, mag)
                out = model(pixel_values=x)
            for j, item in enumerate(items):
                xyxy, scores, labels = decode_image(
                    out.logits[j].float(),
                    out.pred_boxes[j].float(),
                    dataset.size,
                    item["letterbox"],
                    item["orig_size"],
                    score_thr=score_thr,
                    topk=topk,
                    class_bias=class_bias,
                )
                results.extend(results_from_arrays(item["image_id"], xyxy, scores, labels, nms_iou, max_det))
            continue

        # tiled inference: build all tiles for the batch, run them together
        tiles = []
        for item in items:
            w, h = item["orig_size"]
            wide = w / max(h, 1) > 2.2
            if tile_aspect:
                # Adaptive policy: wide strips get aspect-matched tiles, large
                # frames get square tiles, and images that already fit the
                # network input are left whole.  An explicit tile_size sets the
                # wide-strip short side without forcing tiles on small frames.
                if wide:
                    th = tile_size or min(h, 800)
                    asp = tile_aspect
                elif w * h > 1_500_000:
                    th = tile_size or 800
                    asp = None
                else:
                    th = max(w, h)
                    asp = None
            else:
                th = tile_size or default_tile_size(w, h)
                asp = None
            if th >= max(w, h) * 0.95:
                tiles.append({"item": item, "box": (0, 0, w, h), "full": True})
            else:
                for box in tile_grid(w, h, int(th), overlap, aspect=asp):
                    tiles.append({"item": item, "box": box, "full": False})
        n_tiles += len(tiles)

        for t0 in range(0, len(tiles), batch_size):
            chunk = tiles[t0 : t0 + batch_size]
            xs, mags = [], []
            for t in chunk:
                img = Image.open(dataset.img_root / t["item"]["file_name"]).convert("RGB")
                x0, y0, x1, y1 = t["box"]
                crop = img.crop((x0, y0, x1, y1))
                from src.data.dataset import letterbox

                canvas, _, lb = letterbox(crop, np.zeros((0, 4), np.float32), dataset.size)
                arr = np.asarray(canvas, np.float32) / 255.0
                xs.append(torch.from_numpy(arr).permute(2, 0, 1))
                mags.append(t["item"]["mag_id"])
            x = torch.stack(xs).to(device)
            mag = torch.tensor(mags, dtype=torch.long, device=device)
            with torch.autocast("cuda", dtype=amp_dtype, enabled=amp_dtype is not None and device.type == "cuda"):
                set_mag_ids(model, mag)
                out = model(pixel_values=x)
            per_image: dict[int, list[tuple]] = defaultdict(list)
            for j, t in enumerate(chunk):
                x0, y0, x1, y1 = t["box"]
                # recompute letterbox for this crop
                crop_w, crop_h = x1 - x0, y1 - y0
                scale = min(dataset.size / crop_w, dataset.size / crop_h)
                nw, nh = max(1, round(crop_w * scale)), max(1, round(crop_h * scale))
                px, py = (dataset.size - nw) // 2, (dataset.size - nh) // 2
                xyxy, scores, labels = decode_image(
                    out.logits[j].float(),
                    out.pred_boxes[j].float(),
                    dataset.size,
                    (scale, px, py),
                    t["item"]["orig_size"],
                    offset=(x0, y0),
                    score_thr=score_thr,
                    topk=topk,
                    class_bias=class_bias,
                )
                per_image[t["item"]["image_id"]].append((xyxy, scores, labels))
            for img_id, parts in per_image.items():
                xyxy = np.concatenate([p[0] for p in parts]) if parts else np.zeros((0, 4), np.float32)
                scores = np.concatenate([p[1] for p in parts]) if parts else np.zeros((0,), np.float32)
                labels = np.concatenate([p[2] for p in parts]) if parts else np.zeros((0,), np.int64)
                results.extend(results_from_arrays(img_id, xyxy, scores, labels, nms_iou, max_det))

    elapsed = time.time() - t_start
    info = {"n_images": n_images, "n_tiles": n_tiles, "elapsed_s": elapsed, "fps": n_images / max(elapsed, 1e-9)}
    return results, info


# --------------------------------------------------------------------------- #
# COCO metrics
# --------------------------------------------------------------------------- #
def coco_metrics(ann_file: str, results: list[dict], max_dets: int = 300) -> dict[str, Any]:
    coco = COCO(ann_file)
    if not results:
        results = [{"image_id": next(iter(coco.imgs)), "category_id": 0, "bbox": [0, 0, 1, 1], "score": 0.0}]
    dt = coco.loadRes(results)
    ev = COCOeval(coco, dt, "bbox")
    ev.params.maxDets = [1, 10, 100, max_dets]
    ev.evaluate()
    ev.accumulate()

    # suppress the verbose summary but keep the numbers
    import contextlib
    import io

    with contextlib.redirect_stdout(io.StringIO()):
        ev.summarize()

    s = ev.stats
    per_class = {}
    precision = ev.eval["precision"]  # [T,R,K,A,M]
    for idx, cat_id in enumerate(ev.params.catIds):
        if cat_id < 0:
            continue
        p = precision[:, :, idx, 0, -1]
        p = p[p > -1]
        per_class[int(cat_id)] = float(p.mean()) if p.size else float("nan")
    per_class50 = {}
    for idx, cat_id in enumerate(ev.params.catIds):
        if cat_id < 0:
            continue
        p = precision[0, :, idx, 0, -1]
        p = p[p > -1]
        per_class50[int(cat_id)] = float(p.mean()) if p.size else float("nan")

    ap_vals = [v for v in per_class.values() if not math.isnan(v)]
    metrics = {
        "mAP": float(s[0]),
        "mAP50": float(s[1]),
        "mAP75": float(s[2]),
        "mAP_S": float(s[3]),
        "mAP_M": float(s[4]),
        "mAP_L": float(s[5]),
        "per_class_AP": per_class,
        "per_class_AP50": per_class50,
        "macro_AP": float(np.mean(ap_vals)) if ap_vals else float("nan"),
        "tail_AP_2": float(np.nanmean([per_class.get(c, np.nan) for c in TAIL_CLASSES_2])),
        "tail_AP_4": float(np.nanmean([per_class.get(c, np.nan) for c in TAIL_CLASSES_4])),
        "num_dets": len(results),
    }
    return metrics


# --------------------------------------------------------------------------- #
# counting / ecology
# --------------------------------------------------------------------------- #
def group_metrics(ann_file: str, results: list[dict]) -> dict[str, dict[str, Any]]:
    """COCO AP computed separately for each acquisition group (A/B/C)."""
    import copy
    import tempfile

    coco = COCO(ann_file)
    groups: dict[str, list[int]] = defaultdict(list)
    for img_id, info in coco.imgs.items():
        groups[info.get("acquisition_group", "?")].append(img_id)
    out: dict[str, dict[str, Any]] = {}
    for g, ids in sorted(groups.items()):
        idset = set(ids)
        sub = copy.deepcopy(coco.dataset)
        sub["images"] = [im for im in sub["images"] if im["id"] in idset]
        sub["annotations"] = [a for a in sub["annotations"] if a["image_id"] in idset]
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(sub, f)
            tmp = f.name
        try:
            m = coco_metrics(tmp, [r for r in results if r["image_id"] in idset])
            out[g] = {
                "n_images": len(ids),
                "mAP": m["mAP"],
                "mAP50": m["mAP50"],
                "mAP75": m["mAP75"],
                "macro_AP": m["macro_AP"],
                "per_class_AP": m["per_class_AP"],
            }
        finally:
            Path(tmp).unlink(missing_ok=True)
    return out


def counts_from_results(results: list[dict], ann_file: str, score_thr: float = 0.30) -> dict[int, dict[int, int]]:
    coco = COCO(ann_file)
    counts = {img_id: {c: 0 for c in range(len(CLASS_NAMES))} for img_id in coco.imgs}
    for r in results:
        if r["score"] >= score_thr:
            counts.setdefault(r["image_id"], {c: 0 for c in range(len(CLASS_NAMES))})
            counts[r["image_id"]][r["category_id"]] = counts[r["image_id"]].get(r["category_id"], 0) + 1
    return counts


def gt_counts(ann_file: str) -> dict[int, dict[int, int]]:
    coco = COCO(ann_file)
    counts = {img_id: {c: 0 for c in range(len(CLASS_NAMES))} for img_id in coco.imgs}
    for ann in coco.anns.values():
        counts[ann["image_id"]][ann["category_id"]] += 1
    return counts


def icc21(x: np.ndarray, y: np.ndarray) -> float:
    """ICC(2,1) for two raters (absolute agreement)."""
    data = np.stack([x, y], axis=1).astype(np.float64)
    n, k = data.shape
    grand = data.mean()
    row = data.mean(axis=1)
    col = data.mean(axis=0)
    ssr = k * ((row - grand) ** 2).sum()
    ssc = n * ((col - grand) ** 2).sum()
    sse = ((data - row[:, None] - col[None, :] + grand) ** 2).sum()
    msr = ssr / (n - 1)
    msc = ssc / (k - 1)
    mse = sse / ((n - 1) * (k - 1))
    denom = msr + (k - 1) * mse + k * (msc - mse) / n
    return float((msr - mse) / denom) if denom != 0 else float("nan")


def ccc(x: np.ndarray, y: np.ndarray) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    cov = ((x - x.mean()) * (y - y.mean())).mean()
    denom = x.var() + y.var() + (x.mean() - y.mean()) ** 2
    return float(2 * cov / denom) if denom > 0 else float("nan")


def counting_metrics(
    pred: dict[int, dict[int, int]],
    gt: dict[int, dict[int, int]],
    classes: tuple[int, ...] | None = None,
) -> dict[str, Any]:
    classes = classes or tuple(range(len(CLASS_NAMES)))
    ids = sorted(set(pred) & set(gt))
    rows = []
    for c in classes:
        p = np.array([pred[i].get(c, 0) for i in ids], float)
        g = np.array([gt[i].get(c, 0) for i in ids], float)
        if g.sum() == 0 and p.sum() == 0:
            continue
        diff = p - g
        mae = float(np.abs(diff).mean())
        rmse = float(np.sqrt((diff ** 2).mean()))
        nz = g > 0
        mape = float(np.mean(np.abs(diff[nz]) / g[nz]) * 100) if nz.any() else float("nan")
        bias = float(diff.mean())
        sd = float(diff.std(ddof=1)) if len(diff) > 1 else float("nan")
        rows.append(
            {
                "class": c,
                "class_name": CLASS_NAMES[c],
                "n_images": len(ids),
                "gt_total": float(g.sum()),
                "pred_total": float(p.sum()),
                "MAE": mae,
                "RMSE": rmse,
                "MAPE": mape,
                "bias": bias,
                "LoA_low": bias - 1.96 * sd,
                "LoA_high": bias + 1.96 * sd,
                "ICC": icc21(g, p),
                "CCC": ccc(g, p),
                "pearson": float(np.corrcoef(g, p)[0, 1]) if g.std() > 0 and p.std() > 0 else float("nan"),
            }
        )
    # total cell count (all classes)
    p_tot = np.array([sum(pred[i].values()) for i in ids], float)
    g_tot = np.array([sum(gt[i].values()) for i in ids], float)
    diff = p_tot - g_tot
    summary = {
        "n_images": len(ids),
        "gt_total": float(g_tot.sum()),
        "pred_total": float(p_tot.sum()),
        "MAE": float(np.abs(diff).mean()),
        "RMSE": float(np.sqrt((diff ** 2).mean())),
        "MAPE": float(np.mean(np.abs(diff[g_tot > 0]) / g_tot[g_tot > 0]) * 100) if (g_tot > 0).any() else float("nan"),
        "bias": float(diff.mean()),
        "ICC": icc21(g_tot, p_tot),
        "CCC": ccc(g_tot, p_tot),
    }
    return {"per_class": rows, "total": summary, "per_image": {"ids": ids, "pred": p_tot.tolist(), "gt": g_tot.tolist()}}


def bray_curtis(a: np.ndarray, b: np.ndarray) -> float:
    a, b = np.asarray(a, float), np.asarray(b, float)
    return float(np.abs(a - b).sum() / max((a + b).sum(), 1e-9))


def shannon(counts: np.ndarray) -> float:
    p = np.asarray(counts, float)
    p = p / max(p.sum(), 1e-9)
    p = p[p > 0]
    return float(-(p * np.log(p)).sum())


def community_metrics(pred: dict[int, dict[int, int]], gt: dict[int, dict[int, int]]) -> dict[str, Any]:
    ids = sorted(set(pred) & set(gt))
    bc, ds = [], []
    for i in ids:
        p = np.array([pred[i].get(c, 0) for c in range(len(CLASS_NAMES))], float)
        g = np.array([gt[i].get(c, 0) for c in range(len(CLASS_NAMES))], float)
        if g.sum() == 0:
            continue
        bc.append(bray_curtis(p, g))
        ds.append(abs(shannon(p) - shannon(g)))
    return {
        "bray_curtis_mean": float(np.mean(bc)) if bc else float("nan"),
        "bray_curtis_median": float(np.median(bc)) if bc else float("nan"),
        "shannon_abs_diff_mean": float(np.mean(ds)) if ds else float("nan"),
        "shannon_abs_diff_median": float(np.median(ds)) if ds else float("nan"),
        "n_images": len(bc),
    }


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def load_checkpoint(path: str, device: torch.device) -> tuple[torch.nn.Module, dict]:
    ckpt = torch.load(path, map_location="cpu", weights_only=True)
    cfg = ckpt.get("config", {})
    model = build_model(
        ckpt=cfg.get("ckpt"),
        num_classes=cfg.get("num_classes", 6),
        film=cfg.get("film", False),
        num_mags=cfg.get("num_mags", 3),
        film_hidden=cfg.get("film_hidden", 128),
        arch=cfg.get("arch", "dfine"),
        denoising=cfg.get("denoising", True),
    )
    state = ckpt.get("model", ckpt)
    model.load_state_dict(state, strict=True)
    model.to(device).eval()
    return model, cfg


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--ann", required=True)
    ap.add_argument("--img-root", default="algae")
    ap.add_argument("--size", type=int, default=None)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--score-thr", type=float, default=0.001)
    ap.add_argument("--tiling", action="store_true")
    ap.add_argument("--tile-size", type=int, default=None)
    ap.add_argument("--tile-aspect", type=float, default=2.0)
    ap.add_argument("--overlap", type=float, default=0.25)
    ap.add_argument("--nms-iou", type=float, default=0.6)
    ap.add_argument("--count-thr", type=float, default=0.3)
    ap.add_argument("--prior-tau", type=float, default=0.0,
                    help="logit-adjustment strength for class priors (0 disables)")
    ap.add_argument("--prior-ann", default="data/coco/annotations/instances_train.json")
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="cuda:0")
    args = ap.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    model, cfg = load_checkpoint(args.ckpt, device)
    size = args.size or cfg.get("size", 1280)
    ds = AlgaeDataset(args.ann, args.img_root, size=size, train=False)
    class_bias = None
    if args.prior_tau:
        import numpy as _np

        ann_train = json.loads(Path(args.prior_ann).read_text())
        counts = _np.zeros(len(CLASS_NAMES))
        for a in ann_train["annotations"]:
            counts[a["category_id"]] += 1
        freq = counts / counts.sum()
        class_bias = (args.prior_tau * _np.log(freq / freq.prod() ** (1 / len(freq)))).astype("float32")
        print("class bias:", class_bias, flush=True)
    results, info = predict_dataset(
        model,
        ds,
        device,
        batch_size=args.batch_size,
        score_thr=args.score_thr,
        tiling=args.tiling,
        tile_size=args.tile_size,
        overlap=args.overlap,
        tile_aspect=args.tile_aspect,
        nms_iou=args.nms_iou,
        class_bias=class_bias,
    )
    metrics = coco_metrics(args.ann, results)
    metrics["per_group"] = group_metrics(args.ann, results)
    gt = gt_counts(args.ann)
    pred = counts_from_results(results, args.ann, args.count_thr)
    metrics["counting"] = counting_metrics(pred, gt)
    metrics["community"] = community_metrics(pred, gt)
    metrics["inference"] = info
    metrics["config"] = cfg
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(metrics, indent=1, default=float))
    (out.parent / (out.stem + "_preds.json")).write_text(json.dumps(results))
    print(json.dumps({k: v for k, v in metrics.items() if k not in ("per_class_AP", "per_class_AP50", "counting", "community")}, indent=1))
    print("per-class AP:", metrics["per_class_AP"])
    print("counting:", metrics["counting"]["total"])


if __name__ == "__main__":
    main()
