"""
Prepare the algae dataset for detection experiments.

Input : <root>/algae/images/{train,val,test} + lables/{train,val}  (YOLO format)
Output: <root>/data/
          coco/annotations/instances_{train,val,test_unlabeled}.json
          coco/annotations/instances_cd{1,2,3}_{train,test}.json
          yolo/... (YOLO-format copy for ultralytics baselines)
          splits/{main.json, folds.json, groups.json}

Acquisition groups are defined by filename range (verified visually + by
cell-centre matching that they are distinct scenes, not duplicate frames):
    A: 00001-00200  (1904x608)
    B: 00201-00600  (800x600)
    C: 00601-00700  (960x600)
    T: 00701-01000  (300 unlabeled test images)
"""
from __future__ import annotations

import argparse
import json
import os
import random
import shutil
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from PIL import Image
from sklearn.model_selection import StratifiedKFold, train_test_split

CLASS_NAMES = [
    "Platymonas",
    "Chlorella",
    "Dunaliella salina",
    "Effrenium",
    "Porphyridium",
    "Haematococcus",
]


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def acquisition_group(idx: int) -> str:
    if 1 <= idx <= 200:
        return "A"
    if 201 <= idx <= 600:
        return "B"
    if 601 <= idx <= 700:
        return "C"
    if 701 <= idx <= 1000:
        return "T"
    return "X"


def find_label(img_path: Path) -> Path | None:
    """images/train/00001.jpg -> lables/train/00001.txt"""
    parts = list(img_path.parts)
    try:
        i = parts.index("images")
    except ValueError:
        return None
    parts[i] = "lables"
    lab = Path(*parts).with_suffix(".txt")
    return lab if lab.exists() else None


def read_yolo_labels(img_path: Path) -> tuple[list[tuple[int, float, float, float, float]], tuple[int, int]]:
    with Image.open(img_path) as im:
        w, h = im.size
    lab = find_label(img_path)
    boxes: list[tuple[int, float, float, float, float]] = []
    if lab is not None:
        for line in lab.read_text().splitlines():
            t = line.split()
            if len(t) == 5:
                boxes.append((int(t[0]), float(t[1]), float(t[2]), float(t[3]), float(t[4])))
    return boxes, (w, h)


def density_bucket(n: int) -> str:
    if n == 0:
        return "neg"
    if n == 1:
        return "one"
    if n <= 3:
        return "few"
    return "dense"


def stratum_key(rec: dict) -> str:
    present = ",".join(str(c) for c in sorted(rec["classes"]))
    return f"{rec['group']}|{present}|{density_bucket(len(rec['boxes']))}"


def merge_rare_strata(keys: list[str], min_count: int = 5) -> list[str]:
    counts = Counter(keys)
    out = []
    for k in keys:
        if counts[k] < min_count:
            g = k.split("|")[0]
            out.append(f"{g}|rare")
        else:
            out.append(k)
    # if the merged bucket is still too small, fall back to group only
    counts2 = Counter(out)
    return [k if counts2[k] >= min_count else f"{k.split('|')[0]}|all" for k in out]


def split_group(records: list[dict], val_frac: float, seed: int) -> tuple[list[dict], list[dict]]:
    """Stratified split inside one acquisition group."""
    keys = merge_rare_strata([stratum_key(r) for r in records])
    if min(Counter(keys).values()) < 2:
        # last resort: plain random split
        rng = random.Random(seed)
        shuffled = records[:]
        rng.shuffle(shuffled)
        n_val = max(1, round(len(shuffled) * val_frac))
        return shuffled[n_val:], shuffled[:n_val]
    train, val = train_test_split(
        records, test_size=val_frac, random_state=seed, stratify=keys
    )
    return train, val


# --------------------------------------------------------------------------- #
# COCO conversion
# --------------------------------------------------------------------------- #
def to_coco(records: list[dict], out_path: Path, split_name: str, unlabeled: bool = False) -> None:
    images, annotations = [], []
    ann_id = 1
    for rec in records:
        w, h = rec["size"]
        images.append(
            {
                "id": rec["id"],
                "file_name": rec["file_name"],
                "width": w,
                "height": h,
                "acquisition_group": rec["group"],
            }
        )
        if unlabeled:
            continue
        for cls, cx, cy, bw, bh in rec["boxes"]:
            x = (cx - bw / 2) * w
            y = (cy - bh / 2) * h
            bw_px, bh_px = bw * w, bh * h
            annotations.append(
                {
                    "id": ann_id,
                    "image_id": rec["id"],
                    "category_id": cls,
                    "bbox": [round(x, 3), round(y, 3), round(bw_px, 3), round(bh_px, 3)],
                    "area": round(bw_px * bh_px, 3),
                    "iscrowd": 0,
                    "segmentation": [],
                }
            )
            ann_id += 1

    coco = {
        "info": {"description": f"Algae microscopy - {split_name}", "version": "1.0"},
        "licenses": [],
        "images": images,
        "annotations": annotations,
        "categories": [
            {"id": i, "name": name, "supercategory": "microalgae"}
            for i, name in enumerate(CLASS_NAMES)
        ],
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(coco, ensure_ascii=False, indent=1))
    print(f"  {out_path.name}: {len(images)} images, {len(annotations)} boxes")


def write_yolo_split(records: list[dict], root: Path, split: str) -> None:
    img_dir = root / "data" / "yolo" / "images" / split
    lab_dir = root / "data" / "yolo" / "labels" / split
    img_dir.mkdir(parents=True, exist_ok=True)
    lab_dir.mkdir(parents=True, exist_ok=True)
    for rec in records:
        src_img = Path(rec["abs_path"])
        dst_img = img_dir / src_img.name
        if not dst_img.exists():
            os.symlink(src_img, dst_img)
        src_lab = find_label(src_img)
        dst_lab = lab_dir / (src_img.stem + ".txt")
        if src_lab is not None:
            if not dst_lab.exists():
                os.symlink(src_lab, dst_lab)
        else:
            dst_lab.write_text("")


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="project root containing the algae/ directory")
    ap.add_argument("--src", default="algae")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--val-frac", type=float, default=0.2)
    args = ap.parse_args()

    root = Path(args.root)
    src = root / args.src
    data = root / "data"
    data.mkdir(exist_ok=True)

    # ---- collect labeled images ------------------------------------------
    records: list[dict] = []
    for split in ("train", "val"):
        for img in sorted((src / "images" / split).glob("*.jpg")):
            idx = int(img.stem)
            boxes, size = read_yolo_labels(img)
            records.append(
                {
                    "id": idx,
                    "file_name": str(img.relative_to(src)),
                    "abs_path": str(img),
                    "split_src": split,
                    "group": acquisition_group(idx),
                    "classes": sorted({b[0] for b in boxes}),
                    "boxes": boxes,
                    "size": size,
                }
            )
    records.sort(key=lambda r: r["id"])
    print(f"labeled images: {len(records)}")
    print("  by group:", Counter(r["group"] for r in records))
    print("  by resolution:", Counter(r["size"] for r in records))
    print("  boxes per class:", dict(sorted(Counter(b[0] for r in records for b in r["boxes"]).items())))

    # ---- duplicate check --------------------------------------------------
    # exact file duplicates
    import hashlib

    digests = defaultdict(list)
    for r in records:
        digests[hashlib.md5(Path(r["abs_path"]).read_bytes()).hexdigest()].append(r["id"])
    exact_dups = {k: v for k, v in digests.items() if len(v) > 1}
    print(f"exact duplicate groups: {len(exact_dups)}")

    # near-duplicate by matching labeled cell centres across images
    # (images from the same scene would share cell positions; verified 0 matches)
    by_group = defaultdict(list)
    for r in records:
        by_group[r["group"]].append(r)
    same_scene_pairs = 0
    for group, recs in by_group.items():
        for i in range(len(recs) - 1):
            a, b = recs[i], recs[i + 1]
            for ca, xa, ya, _, _ in a["boxes"]:
                for cb, xb, yb, _, _ in b["boxes"]:
                    if ca == cb and abs(xa - xb) * a["size"][0] < 20 and abs(ya - yb) * a["size"][1] < 20:
                        same_scene_pairs += 1
                        break
    print(f"same-cell matches between consecutive images: {same_scene_pairs}")

    # ---- main split -------------------------------------------------------
    train, val = [], []
    for group in ("A", "B", "C"):
        g_train, g_val = split_group([r for r in records if r["group"] == group], args.val_frac, args.seed)
        train.extend(g_train)
        val.extend(g_val)
    train.sort(key=lambda r: r["id"])
    val.sort(key=lambda r: r["id"])
    print(f"main split: train={len(train)} val={len(val)}")
    for name, part in [("train", train), ("val", val)]:
        print(f"  {name} groups:", Counter(r["group"] for r in part))
        print(f"  {name} classes:", dict(sorted(Counter(b[0] for r in part for b in r["boxes"]).items())))

    # sanity: every class present in both
    for c in range(len(CLASS_NAMES)):
        assert any(c in r["classes"] for r in train), f"class {c} missing from train"
        assert any(c in r["classes"] for r in val), f"class {c} missing from val"

    # ---- 5-fold on the 560 training images -------------------------------
    keys = merge_rare_strata([stratum_key(r) for r in train], min_count=10)
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=args.seed)
    folds = []
    for fold, (tr_idx, va_idx) in enumerate(skf.split(train, keys)):
        folds.append(
            {
                "fold": fold,
                "train_ids": [train[i]["id"] for i in tr_idx],
                "val_ids": [train[i]["id"] for i in va_idx],
            }
        )
    print("5-fold sizes:", [(len(f["train_ids"]), len(f["val_ids"])) for f in folds])

    # ---- COCO outputs -----------------------------------------------------
    print("writing COCO annotations...")
    to_coco(train, data / "coco" / "annotations" / "instances_train.json", "train")
    to_coco(val, data / "coco" / "annotations" / "instances_val.json", "val")

    # unlabeled test images
    test_recs = []
    test_dir = src / "images" / "test"
    for img in sorted(test_dir.glob("*.jpg")):
        idx = int(img.stem)
        with Image.open(img) as im:
            size = im.size
        test_recs.append(
            {
                "id": idx,
                "file_name": f"images/test/{img.name}",
                "abs_path": str(img),
                "group": acquisition_group(idx),
                "classes": [],
                "boxes": [],
                "size": size,
            }
        )
    to_coco(test_recs, data / "coco" / "annotations" / "instances_test_unlabeled.json", "test", unlabeled=True)
    print(f"unlabeled test: {len(test_recs)} images, resolutions {Counter(r['size'] for r in test_recs)}")

    # ---- cross-domain splits ---------------------------------------------
    print("writing cross-domain splits...")
    cd_specs = {
        "cd1_trainB_testA": ([r for r in records if r["group"] == "B"], [r for r in records if r["group"] == "A"]),
        "cd2_trainAB_testC": ([r for r in records if r["group"] in ("A", "B")], [r for r in records if r["group"] == "C"]),
        "cd3_trainAC_testB": ([r for r in records if r["group"] in ("A", "C")], [r for r in records if r["group"] == "B"]),
    }
    for name, (tr, te) in cd_specs.items():
        to_coco(tr, data / "coco" / "annotations" / f"instances_{name}_train.json", f"{name}_train")
        to_coco(te, data / "coco" / "annotations" / f"instances_{name}_test.json", f"{name}_test")

    # ---- YOLO-format dataset ---------------------------------------------
    print("writing YOLO-format dataset...")
    write_yolo_split(train, root, "train")
    write_yolo_split(val, root, "val")
    write_yolo_split(test_recs, root, "test")
    yaml = data / "yolo" / "data.yaml"
    yaml.write_text(
        "path: " + str((data / "yolo").resolve()) + "\n"
        "train: images/train\nval: images/val\ntest: images/test\n\n"
        f"nc: {len(CLASS_NAMES)}\nnames: {json.dumps(CLASS_NAMES, ensure_ascii=False)}\n"
    )

    # ---- split metadata ---------------------------------------------------
    splits_dir = data / "splits"
    splits_dir.mkdir(parents=True, exist_ok=True)
    (splits_dir / "main.json").write_text(
        json.dumps(
            {
                "train_ids": [r["id"] for r in train],
                "val_ids": [r["id"] for r in val],
                "test_unlabeled_ids": [r["id"] for r in test_recs],
                "seed": args.seed,
                "val_frac": args.val_frac,
            },
            indent=1,
        )
    )
    (splits_dir / "folds.json").write_text(json.dumps(folds, indent=1))
    (splits_dir / "groups.json").write_text(
        json.dumps({r["id"]: r["group"] for r in records}, indent=1)
    )
    (splits_dir / "audit.json").write_text(
        json.dumps(
            {
                "n_labeled": len(records),
                "n_test_unlabeled": len(test_recs),
                "exact_duplicate_groups": exact_dups,
                "same_cell_matches_consecutive": same_scene_pairs,
                "class_names": CLASS_NAMES,
            },
            indent=1,
        )
    )
    print("done.")


if __name__ == "__main__":
    main()
