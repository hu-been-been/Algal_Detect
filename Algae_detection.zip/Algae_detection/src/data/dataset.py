"""Dataset and sampling utilities for the algae detection experiments.

Images are letterboxed to a square canvas of side `size`.  Boxes are returned in
normalised ``cxcywh`` format, which is what the D-FINE / RT-DETR family expects.

The acquisition domain is encoded as a magnification id
(``0`` = wide strip 1904x608, ``1`` = 800x600, ``2`` = 960x600 / 1920x1200).
It is derived from the image size so that the same function works for the
unlabeled test images (which carry no group label in their filenames beyond
the range).
"""
from __future__ import annotations

import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image, ImageEnhance
from pycocotools.coco import COCO
from torch.utils.data import Dataset, WeightedRandomSampler

CLASS_NAMES = [
    "Platymonas",
    "Chlorella",
    "Dunaliella salina",
    "Effrenium",
    "Porphyridium",
    "Haematococcus",
]

# classes that are scarce in the training split (instance counts < 300)
RARE_CLASSES = (0, 2, 3, 5)


# --------------------------------------------------------------------------- #
# geometry helpers
# --------------------------------------------------------------------------- #
def xywh_to_xyxy(b: np.ndarray) -> np.ndarray:
    out = b.copy().astype(np.float32)
    out[:, 2] = b[:, 0] + b[:, 2]
    out[:, 3] = b[:, 1] + b[:, 3]
    return out


def xyxy_to_xywh(b: np.ndarray) -> np.ndarray:
    out = b.copy().astype(np.float32)
    out[:, 2] = b[:, 2] - b[:, 0]
    out[:, 3] = b[:, 3] - b[:, 1]
    return out


def clip_boxes(b: np.ndarray, w: int, h: int) -> np.ndarray:
    b = b.copy()
    b[:, 0::2] = b[:, 0::2].clip(0, w)
    b[:, 1::2] = b[:, 1::2].clip(0, h)
    return b


def mag_id_from_size(w: int, h: int) -> int:
    """Map an image size to one of the three acquisition-scale buckets."""
    aspect = w / max(h, 1)
    if aspect > 2.2:
        return 0  # 1904x608 wide strip
    if w * h < 520_000:
        return 1  # 800x600
    return 2  # 960x600, 1920x1200


def letterbox(
    img: Image.Image,
    boxes: np.ndarray,
    size: int,
    fill: int = 114,
) -> tuple[Image.Image, np.ndarray, tuple[float, int, int]]:
    """Resize preserving aspect ratio and pad to ``size x size``.

    ``boxes`` are xyxy in the input image.  Returns the canvas, the boxes in
    canvas pixels, and ``(scale, pad_x, pad_y)`` for the inverse mapping.
    """
    w, h = img.size
    scale = min(size / w, size / h)
    nw, nh = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
    resized = img.resize((nw, nh), Image.BILINEAR)
    canvas = Image.new("RGB", (size, size), (fill, fill, fill))
    px, py = (size - nw) // 2, (size - nh) // 2
    canvas.paste(resized, (px, py))
    if len(boxes):
        boxes = boxes * scale + np.array([px, py, px, py], dtype=np.float32)
    return canvas, boxes, (scale, px, py)


def random_crop(
    img: Image.Image,
    boxes: np.ndarray,
    min_aspect: float = 1.8,
    max_aspect: float = 2.2,
    min_keep: float = 0.35,
) -> tuple[Image.Image, np.ndarray, np.ndarray]:
    """Crop a wide image to roughly 2:1 so objects are not shrunk by letterbox.

    Returns the crop, the cropped boxes, and the boolean mask of kept boxes.
    """
    w, h = img.size
    cw = int(round(h * random.uniform(min_aspect, max_aspect)))
    cw = min(cw, w)
    if cw >= w:
        return img, boxes, np.ones(len(boxes), dtype=bool)
    x0 = random.randint(0, w - cw)
    crop = img.crop((x0, 0, x0 + cw, h))
    if not len(boxes):
        return crop, boxes, np.zeros(0, dtype=bool)
    b = boxes - np.array([x0, 0, x0, 0], dtype=np.float32)
    # keep boxes with enough overlap with the crop
    iw = np.minimum(b[:, 2], cw) - np.maximum(b[:, 0], 0)
    ih = np.minimum(b[:, 3], h) - np.maximum(b[:, 1], 0)
    inter = np.maximum(iw, 0) * np.maximum(ih, 0)
    area = np.maximum(boxes[:, 2] - boxes[:, 0], 1e-6) * np.maximum(boxes[:, 3] - boxes[:, 1], 1e-6)
    keep = inter / area >= min_keep
    return crop, clip_boxes(b, cw, h)[keep], keep


def random_scale_crop(
    img: Image.Image,
    boxes: np.ndarray,
    scale_range: tuple[float, float] = (0.7, 1.0),
    min_keep: float = 0.5,
) -> tuple[Image.Image, np.ndarray, np.ndarray]:
    """Generic zoom-in crop (centred on a random box)."""
    w, h = img.size
    if len(boxes) == 0:
        return img, boxes, np.ones(0, dtype=bool)
    s = random.uniform(*scale_range)
    cw, ch = max(32, int(w * s)), max(32, int(h * s))
    # centre the crop on a randomly chosen box so it is not lost
    cx, cy = boxes[random.randrange(len(boxes))][:2]
    x0 = int(np.clip(cx - cw / 2 + random.uniform(-0.2, 0.2) * cw, 0, w - cw))
    y0 = int(np.clip(cy - ch / 2 + random.uniform(-0.2, 0.2) * ch, 0, h - ch))
    crop = img.crop((x0, y0, x0 + cw, y0 + ch))
    b = boxes - np.array([x0, y0, x0, y0], dtype=np.float32)
    iw = np.minimum(b[:, 2], cw) - np.maximum(b[:, 0], 0)
    ih = np.minimum(b[:, 3], ch) - np.maximum(b[:, 1], 0)
    inter = np.maximum(iw, 0) * np.maximum(ih, 0)
    area = np.maximum(boxes[:, 2] - boxes[:, 0], 1e-6) * np.maximum(boxes[:, 3] - boxes[:, 1], 1e-6)
    keep = inter / area >= min_keep
    return crop, clip_boxes(b, cw, ch)[keep], keep


def hflip(img: Image.Image, boxes: np.ndarray) -> tuple[Image.Image, np.ndarray]:
    w, h = img.size
    img = img.transpose(Image.FLIP_LEFT_RIGHT)
    if len(boxes):
        x1 = w - boxes[:, 2]
        x2 = w - boxes[:, 0]
        boxes = boxes.copy()
        boxes[:, 0], boxes[:, 2] = x1, x2
    return img, boxes


def vflip(img: Image.Image, boxes: np.ndarray) -> tuple[Image.Image, np.ndarray]:
    w, h = img.size
    img = img.transpose(Image.FLIP_TOP_BOTTOM)
    if len(boxes):
        y1 = h - boxes[:, 3]
        y2 = h - boxes[:, 1]
        boxes = boxes.copy()
        boxes[:, 1], boxes[:, 3] = y1, y2
    return img, boxes


def color_jitter(img: Image.Image, strength: float = 0.1) -> Image.Image:
    if strength <= 0:
        return img
    b = 1 + random.uniform(-strength, strength)
    c = 1 + random.uniform(-strength, strength)
    s = 1 + random.uniform(-strength, strength)
    img = ImageEnhance.Brightness(img).enhance(b)
    img = ImageEnhance.Contrast(img).enhance(c)
    img = ImageEnhance.Color(img).enhance(s)
    return img


# --------------------------------------------------------------------------- #
# copy-paste donors
# --------------------------------------------------------------------------- #
class CopyPastePool:
    """Crops of rare-class cells, grouped by acquisition domain.

    Donor and recipient must come from the same acquisition group so that the
    background statistics match; otherwise the paste is an obvious seam.
    """

    def __init__(self, coco: COCO, img_root: Path, classes=RARE_CLASSES, margin: int = 2):
        self.img_root = Path(img_root)
        self.margin = margin
        self.by_group: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for img_id, info in coco.imgs.items():
            g = info.get("acquisition_group", "?")
            for ann in coco.imgToAnns.get(img_id, []):
                if ann["category_id"] not in classes:
                    continue
                x, y, w, h = ann["bbox"]
                if w < 4 or h < 4:
                    continue
                self.by_group[g].append(
                    {
                        "path": str(self.img_root / info["file_name"]),
                        "bbox": (x, y, w, h),
                        "cls": ann["category_id"],
                    }
                )
        for g in self.by_group:
            random.shuffle(self.by_group[g])

    def sample(self, group: str, cls: int | None = None) -> dict[str, Any] | None:
        pool = self.by_group.get(group, [])
        if not pool:
            return None
        if cls is not None:
            pool = [d for d in pool if d["cls"] == cls]
            if not pool:
                return None
        return random.choice(pool)


def paste_objects(
    img: Image.Image,
    boxes: np.ndarray,
    labels: np.ndarray,
    pool: CopyPastePool,
    group: str,
    n: int = 1,
    max_tries: int = 20,
) -> tuple[np.ndarray, np.ndarray]:
    """Paste ``n`` rare cells onto the image; returns updated xyxy boxes/labels."""
    w, h = img.size
    for _ in range(n):
        donor = pool.sample(group)
        if donor is None:
            break
        x, y, bw, bh = donor["bbox"]
        m = pool.margin
        try:
            src = Image.open(donor["path"]).convert("RGB")
        except Exception:
            continue
        crop = src.crop(
            (
                max(0, int(x) - m),
                max(0, int(y) - m),
                min(src.width, int(x + bw) + m),
                min(src.height, int(y + bh) + m),
            )
        )
        if random.random() < 0.5:
            crop = crop.transpose(Image.FLIP_LEFT_RIGHT)
        # scale donor between 0.8x and 1.3x
        s = random.uniform(0.8, 1.3)
        cw, ch = max(3, int(crop.width * s)), max(3, int(crop.height * s))
        if cw >= w or ch >= h:
            continue
        crop = crop.resize((cw, ch), Image.BILINEAR)
        for _try in range(max_tries):
            px = random.randint(0, w - cw)
            py = random.randint(0, h - ch)
            new = np.array([px, py, px + cw, py + ch], dtype=np.float32)
            if len(boxes):
                ix1 = np.maximum(boxes[:, 0], new[0])
                iy1 = np.maximum(boxes[:, 1], new[1])
                ix2 = np.minimum(boxes[:, 2], new[2])
                iy2 = np.minimum(boxes[:, 3], new[3])
                inter = np.maximum(ix2 - ix1, 0) * np.maximum(iy2 - iy1, 0)
                if (inter / max(cw * ch, 1)).max() > 0.05:
                    continue
            img.paste(crop, (px, py))
            boxes = np.vstack([boxes, new[None]]) if len(boxes) else new[None]
            labels = np.concatenate([labels, np.array([donor["cls"]], dtype=np.int64)])
            break
    return boxes, labels


# --------------------------------------------------------------------------- #
# dataset
# --------------------------------------------------------------------------- #
class AlgaeDataset(Dataset):
    def __init__(
        self,
        ann_file: str,
        img_root: str,
        size: int = 1280,
        train: bool = False,
        tile_train: bool = True,
        tile_prob: float = 0.5,
        hflip: float = 0.5,
        vflip: float = 0.5,
        color_jitter_strength: float = 0.1,
        copy_paste: float = 0.0,
        copy_paste_classes: tuple[int, ...] = RARE_CLASSES,
        scale_crop_prob: float = 0.25,
        seed: int = 0,
        max_samples: int | None = None,
        preload: bool = False,
    ):
        self.coco = COCO(ann_file)
        self.img_root = Path(img_root)
        self.size = size
        self.train = train
        self.tile_train = tile_train
        self.tile_prob = tile_prob
        self.hflip = hflip
        self.vflip = vflip
        self.color_jitter_strength = color_jitter_strength
        self.copy_paste = copy_paste
        self.scale_crop_prob = scale_crop_prob
        self.rng = random.Random(seed)

        self.ids = sorted(self.coco.imgs.keys())
        if max_samples is not None and max_samples < len(self.ids):
            # stratified-ish subsample by acquisition group
            by_g: dict[str, list[int]] = defaultdict(list)
            for i in self.ids:
                by_g[self.coco.imgs[i].get("acquisition_group", "?")].append(i)
            keep: list[int] = []
            for g, lst in by_g.items():
                k = max(1, round(len(lst) * max_samples / len(self.ids)))
                keep.extend(self.rng.sample(lst, min(k, len(lst))))
            self.ids = sorted(keep)

        self.pool = None
        if train and copy_paste > 0:
            self.pool = CopyPastePool(self.coco, self.img_root, copy_paste_classes)

        self._cache: dict[int, Image.Image] = {}
        if preload:
            for i in self.ids:
                self._cache[i] = Image.open(self.img_root / self.coco.imgs[i]["file_name"]).convert("RGB")

    def __len__(self) -> int:
        return len(self.ids)

    def _load_image(self, img_id: int) -> Image.Image:
        if img_id in self._cache:
            return self._cache[img_id].copy()
        path = self.img_root / self.coco.imgs[img_id]["file_name"]
        with Image.open(path) as im:
            return im.convert("RGB")

    def __getitem__(self, idx: int) -> dict[str, Any]:
        img_id = self.ids[idx]
        info = self.coco.imgs[img_id]
        img = self._load_image(img_id)
        w0, h0 = img.size

        anns = self.coco.imgToAnns.get(img_id, [])
        if anns:
            boxes = np.array([a["bbox"] for a in anns], dtype=np.float32)
            boxes = xywh_to_xyxy(boxes)
            labels = np.array([a["category_id"] for a in anns], dtype=np.int64)
        else:
            boxes = np.zeros((0, 4), dtype=np.float32)
            labels = np.zeros((0,), dtype=np.int64)

        group = info.get("acquisition_group", "?")
        mag_id = mag_id_from_size(w0, h0)

        if self.train:
            # wide strips: random 2:1 crop so cells are not down-scaled
            if self.tile_train and w0 / max(h0, 1) > 2.2 and self.rng.random() < self.tile_prob:
                img, boxes, keep = random_crop(img, boxes)
                labels = labels[keep]
            elif len(boxes) and self.rng.random() < self.scale_crop_prob:
                img, boxes, keep = random_scale_crop(img, boxes)
                labels = labels[keep]

            if self.rng.random() < self.hflip:
                img, boxes = hflip(img, boxes)
            if self.rng.random() < self.vflip:
                img, boxes = vflip(img, boxes)
            if self.color_jitter_strength > 0:
                img = color_jitter(img, self.color_jitter_strength)

            if self.pool is not None and self.rng.random() < self.copy_paste:
                n = 1 + (self.rng.random() < 0.3)
                boxes, labels = paste_objects(img, boxes, labels, self.pool, group, n=n)

        # final sanitisation
        if len(boxes):
            boxes = clip_boxes(boxes, img.width, img.height)
            wh = boxes[:, 2:] - boxes[:, :2]
            keep = (wh[:, 0] >= 2) & (wh[:, 1] >= 2)
            boxes, labels = boxes[keep], labels[keep]

        canvas, boxes_c, (scale, pad_x, pad_y) = letterbox(img, boxes, self.size)
        arr = np.asarray(canvas, dtype=np.float32) / 255.0
        pixel_values = torch.from_numpy(arr).permute(2, 0, 1).contiguous()

        if len(boxes_c):
            cx = (boxes_c[:, 0] + boxes_c[:, 2]) / (2 * self.size)
            cy = (boxes_c[:, 1] + boxes_c[:, 3]) / (2 * self.size)
            bw = (boxes_c[:, 2] - boxes_c[:, 0]) / self.size
            bh = (boxes_c[:, 3] - boxes_c[:, 1]) / self.size
            norm_boxes = np.stack([cx, cy, bw, bh], axis=1).astype(np.float32)
            norm_boxes = np.clip(norm_boxes, 0.0, 1.0)
        else:
            norm_boxes = np.zeros((0, 4), dtype=np.float32)

        return {
            "pixel_values": pixel_values,
            "labels": {
                "class_labels": torch.from_numpy(labels).long(),
                "boxes": torch.from_numpy(norm_boxes).float(),
            },
            "image_id": int(img_id),
            "orig_size": (w0, h0),
            "mag_id": int(mag_id),
            "group": group,
            "letterbox": (float(scale), int(pad_x), int(pad_y)),
            "file_name": info["file_name"],
        }

    # ------------------------------------------------------------------ #
    def class_counts(self) -> Counter:
        c: Counter = Counter()
        for i in self.ids:
            for a in self.coco.imgToAnns.get(i, []):
                c[a["category_id"]] += 1
        return c


def collate_fn(batch: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "pixel_values": torch.stack([b["pixel_values"] for b in batch], dim=0),
        "labels": [b["labels"] for b in batch],
        "image_ids": [b["image_id"] for b in batch],
        "orig_sizes": [b["orig_size"] for b in batch],
        "mag_ids": torch.tensor([b["mag_id"] for b in batch], dtype=torch.long),
        "groups": [b["group"] for b in batch],
        "letterboxes": [b["letterbox"] for b in batch],
        "file_names": [b["file_name"] for b in batch],
    }


def rfs_weights(dataset: AlgaeDataset, cap: float = 3.0) -> np.ndarray:
    """Repeat-factor sampling weights per image (image-level class frequency)."""
    counts = dataset.class_counts()
    if not counts:
        return np.ones(len(dataset), dtype=np.float64)
    max_f = max(counts.values())
    freqs = {c: n for c, n in counts.items()}
    weights = np.ones(len(dataset), dtype=np.float64)
    for i, img_id in enumerate(dataset.ids):
        present = {a["category_id"] for a in dataset.coco.imgToAnns.get(img_id, [])}
        if not present:
            weights[i] = 1.0
            continue
        weights[i] = min(cap, max(math.sqrt(max_f / max(freqs.get(c, 1), 1)) for c in present))
    return weights


def make_rfs_sampler(dataset: AlgaeDataset, cap: float = 3.0, num_samples: int | None = None):
    w = rfs_weights(dataset, cap=cap)
    return WeightedRandomSampler(
        weights=torch.as_tensor(w, dtype=torch.double),
        num_samples=num_samples or len(dataset),
        replacement=True,
    )


def load_split_ids(splits_file: str, key: str) -> list[int]:
    return json.loads(Path(splits_file).read_text())[key]
