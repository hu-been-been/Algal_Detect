"""Sweep inference tile size for a trained checkpoint.

For wide-strip images the useful magnification depends on the tile size; this
script measures mAP and per-acquisition-group mAP for several tile sizes so the
adaptive policy can be set from data rather than guesswork.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.dataset import AlgaeDataset
from src.evaluate import coco_metrics, group_metrics, load_checkpoint, predict_dataset


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--ann", default="data/coco/annotations/instances_val.json")
    ap.add_argument("--img-root", default="algae")
    ap.add_argument("--tile-sizes", default="608,768,960,1216,1536")
    ap.add_argument("--overlap", type=float, default=0.25)
    ap.add_argument("--tile-aspect", type=float, default=2.0)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="cuda:0")
    args = ap.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    model, cfg = load_checkpoint(args.ckpt, device)
    ds = AlgaeDataset(args.ann, args.img_root, size=cfg.get("size", 1280), train=False)
    rows = []
    for ts in [int(x) for x in args.tile_sizes.split(",")]:
        preds, info = predict_dataset(
            model, ds, device, batch_size=args.batch_size, score_thr=0.001,
            tiling=True, tile_size=ts, overlap=args.overlap, tile_aspect=args.tile_aspect,
        )
        m = coco_metrics(args.ann, preds)
        g = group_metrics(args.ann, preds)
        row = {
            "tile_size": ts,
            "overlap": args.overlap,
            "tile_aspect": args.tile_aspect,
            "mAP": m["mAP"],
            "mAP50": m["mAP50"],
            "macro_AP": m["macro_AP"],
            "tail_AP_2": m["tail_AP_2"],
            "per_group": {k: v["mAP"] for k, v in g.items()},
            "fps": info["fps"],
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rows, indent=1))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
