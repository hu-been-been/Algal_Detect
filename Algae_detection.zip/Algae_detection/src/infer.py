"""Run a trained detector on a COCO split (labeled or unlabeled) and save detections."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.dataset import CLASS_NAMES, AlgaeDataset
from src.evaluate import load_checkpoint, predict_dataset

COLORS = [
    (220, 50, 47),
    (38, 139, 210),
    (133, 153, 0),
    (211, 54, 130),
    (108, 113, 196),
    (203, 75, 22),
]


def draw(image_path: Path, dets: list[dict], out_path: Path, gt: list[dict] | None = None) -> None:
    img = Image.open(image_path).convert("RGB")
    dr = ImageDraw.Draw(img)
    if gt:
        for a in gt:
            x, y, w, h = a["bbox"]
            dr.rectangle([x, y, x + w, y + h], outline=(0, 160, 0), width=2)
    for d in dets:
        x, y, w, h = d["bbox"]
        c = COLORS[int(d["category_id"]) % len(COLORS)]
        dr.rectangle([x, y, x + w, y + h], outline=c, width=2)
        dr.text((x + 2, max(0, y - 10)), f"{CLASS_NAMES[int(d['category_id'])]} {d['score']:.2f}", fill=c)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path, quality=92)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--ann", required=True)
    ap.add_argument("--img-root", default="algae")
    ap.add_argument("--out", required=True)
    ap.add_argument("--size", type=int, default=None)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--score-thr", type=float, default=0.05)
    ap.add_argument("--tiling", action="store_true")
    ap.add_argument("--tile-size", type=int, default=None)
    ap.add_argument("--tile-aspect", type=float, default=2.0)
    ap.add_argument("--overlap", type=float, default=0.25)
    ap.add_argument("--nms-iou", type=float, default=0.6)
    ap.add_argument("--viz-dir", default=None)
    ap.add_argument("--n-viz", type=int, default=12)
    ap.add_argument("--device", default="cuda:0")
    args = ap.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    model, cfg = load_checkpoint(args.ckpt, device)
    size = args.size or cfg.get("size", 1280)
    ds = AlgaeDataset(args.ann, args.img_root, size=size, train=False)
    results, info = predict_dataset(
        model,
        ds,
        device,
        batch_size=args.batch_size,
        score_thr=args.score_thr,
        tiling=args.tiling,
        tile_size=args.tile_size,
        overlap=args.overlap,
        tile_aspect=args.tile_aspect,
        nms_iou=args.nms_iou,
    )
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results))
    print(json.dumps({"n_dets": len(results), **info}, indent=1))

    if args.viz_dir:
        by_img: dict[int, list[dict]] = {}
        for r in results:
            by_img.setdefault(r["image_id"], []).append(r)
        coco = ds.coco
        for img_id in list(by_img)[: args.n_viz]:
            info_i = coco.imgs[img_id]
            gt = coco.imgToAnns.get(img_id, []) or None
            draw(
                Path(args.img_root) / info_i["file_name"],
                by_img[img_id],
                Path(args.viz_dir) / f"{img_id:05d}.jpg",
                gt=gt,
            )
        print(f"wrote {min(len(by_img), args.n_viz)} visualisations to {args.viz_dir}")


if __name__ == "__main__":
    main()
