"""Train D-FINE-S (optionally with FiLM / NWD / RFS / Copy-Paste)."""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.dataset import AlgaeDataset, collate_fn, make_rfs_sampler
from src.evaluate import coco_metrics, predict_dataset
from src.losses.nwd import enable_nwd
from src.models.build import ModelEMA, build_model, count_params, make_param_groups, set_mag_ids


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--ann-train", default="data/coco/annotations/instances_train.json")
    ap.add_argument("--ann-val", default="data/coco/annotations/instances_val.json")
    ap.add_argument("--ann-test", default=None, help="held-out test set for the final evaluation")
    ap.add_argument("--img-root", default="algae")
    ap.add_argument("--ckpt", default=None)
    ap.add_argument("--init-from", default=None, help="load weights from a previous run's best.pt")
    ap.add_argument("--arch", choices=["dfine", "rtdetr"], default="dfine")
    ap.add_argument("--out-dir", default="runs")
    ap.add_argument("--size", type=int, default=1280)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--backbone-lr-mult", type=float, default=0.1)
    ap.add_argument("--weight-decay", type=float, default=1e-4)
    ap.add_argument("--warmup-epochs", type=int, default=5)
    ap.add_argument("--grad-clip", type=float, default=0.1)
    ap.add_argument("--ema-decay", type=float, default=0.999)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--num-workers", type=int, default=6)
    ap.add_argument("--val-interval", type=int, default=5)
    ap.add_argument("--amp", choices=["bf16", "fp16", "none"], default="bf16")
    ap.add_argument("--film", action="store_true")
    ap.add_argument("--no-denoising", dest="denoising", action="store_false")
    ap.add_argument("--head-prior", default=None,
                    help="class priors for the reinitialised head: 'data' or comma-separated floats")
    ap.add_argument("--film-hidden", type=int, default=128)
    ap.add_argument("--num-mags", type=int, default=3)
    ap.add_argument("--nwd", action="store_true")
    ap.add_argument("--nwd-weight", type=float, default=0.5)
    ap.add_argument("--nwd-c", type=float, default=0.05)
    ap.add_argument("--rfs", action="store_true")
    ap.add_argument("--copy-paste", type=float, default=0.0)
    ap.add_argument("--tile-train", action="store_true", default=True)
    ap.add_argument("--no-tile-train", dest="tile_train", action="store_false")
    ap.add_argument("--tile-prob", type=float, default=0.5)
    ap.add_argument("--scale-crop-prob", type=float, default=0.25)
    ap.add_argument("--hflip", type=float, default=0.5)
    ap.add_argument("--vflip", type=float, default=0.5)
    ap.add_argument("--color-jitter", type=float, default=0.1)
    ap.add_argument("--limit-train", type=int, default=None, help="use only N training images (learning curve)")
    ap.add_argument("--eval-tiling", action="store_true")
    ap.add_argument("--tile-size", type=int, default=None)
    ap.add_argument("--tile-aspect", type=float, default=2.0,
                    help="tile aspect for wide strips (matches the 2:1 training crop); 0 disables")
    ap.add_argument("--overlap", type=float, default=0.25)
    ap.add_argument("--patience", type=int, default=0)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--no-ema", action="store_true")
    args = ap.parse_args()
    if args.tile_train is False:
        args.tile_prob = 0.0
    return args


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def worker_init(worker_id: int) -> None:
    seed = torch.initial_seed() % (2**31)
    random.seed(seed)
    np.random.seed(seed)


def build_loaders(args: argparse.Namespace):
    train_ds = AlgaeDataset(
        args.ann_train,
        args.img_root,
        size=args.size,
        train=True,
        tile_train=args.tile_train,
        tile_prob=args.tile_prob,
        hflip=args.hflip,
        vflip=args.vflip,
        color_jitter_strength=args.color_jitter,
        copy_paste=args.copy_paste,
        scale_crop_prob=args.scale_crop_prob,
        seed=args.seed,
        max_samples=args.limit_train,
    )
    val_ds = AlgaeDataset(args.ann_val, args.img_root, size=args.size, train=False)
    sampler = make_rfs_sampler(train_ds) if args.rfs else None
    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=sampler is None,
        sampler=sampler,
        num_workers=args.num_workers,
        collate_fn=collate_fn,
        pin_memory=True,
        drop_last=False,
        persistent_workers=args.num_workers > 0,
        prefetch_factor=4 if args.num_workers > 0 else None,
        worker_init_fn=worker_init,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=max(1, args.batch_size),
        shuffle=False,
        num_workers=max(2, args.num_workers // 2),
        collate_fn=collate_fn,
        pin_memory=True,
        persistent_workers=args.num_workers > 0,
    )
    return train_ds, val_ds, train_loader, val_loader


def lr_lambda(epoch: int, warmup: int, total: int) -> float:
    if epoch < warmup:
        return (epoch + 1) / max(warmup, 1)
    p = (epoch - warmup) / max(total - warmup, 1)
    return max(0.01, 0.5 * (1 + math.cos(math.pi * p)))


def evaluate(
    model,
    ds,
    args,
    device,
    tiling: bool | None = None,
    groups: bool = False,
    ann_file: str | None = None,
) -> dict:
    use_tiling = args.eval_tiling if tiling is None else tiling
    ann_file = ann_file or args.ann_val
    results, info = predict_dataset(
        model,
        ds,
        device,
        batch_size=max(4, args.batch_size),
        score_thr=0.001,
        tiling=use_tiling,
        tile_size=args.tile_size,
        overlap=args.overlap,
        tile_aspect=args.tile_aspect,
    )
    m = coco_metrics(ann_file, results)
    m["inference"] = info
    if groups:
        from src.evaluate import group_metrics

        m["per_group"] = group_metrics(ann_file, results)
    return m


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    out_dir = Path(args.out_dir) / args.run_id
    out_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    if args.nwd:
        enable_nwd(args.nwd_weight, args.nwd_c)

    head_prior = None
    if args.head_prior:
        if args.head_prior == "data":
            import json as _json

            ann = _json.loads(Path(args.ann_train).read_text())
            counts = [0] * 6
            for a in ann["annotations"]:
                counts[a["category_id"]] += 1
            total = sum(counts)
            freq = [c / total for c in counts]
            # Keep the average initial objectness at D-FINE's 0.01 and only let
            # the class frequencies shape the relative priors.
            mean_f = sum(freq) / len(freq)
            head_prior = [min(0.05, 0.01 * f / mean_f) for f in freq]
        else:
            head_prior = [float(v) for v in args.head_prior.split(",")]
        print(f"[{args.run_id}] head prior {head_prior}", flush=True)

    model = build_model(
        ckpt=args.ckpt,
        num_classes=6,
        film=args.film,
        num_mags=args.num_mags,
        film_hidden=args.film_hidden,
        arch=args.arch,
        denoising=args.denoising,
        head_prior=head_prior,
    ).to(device)

    if args.init_from:
        init = torch.load(args.init_from, map_location="cpu", weights_only=False)
        model.load_state_dict(init["model"], strict=True)
        print(f"[{args.run_id}] initialised from {args.init_from}", flush=True)

    cfg = vars(args).copy()
    cfg.update(
        {
            "num_classes": 6,
            "class_names": [
                "Platymonas",
                "Chlorella",
                "Dunaliella salina",
                "Effrenium",
                "Porphyridium",
                "Haematococcus",
            ],
            "params": count_params(model),
        }
    )
    (out_dir / "config.json").write_text(json.dumps(cfg, indent=1))

    train_ds, val_ds, train_loader, _ = build_loaders(args)
    print(
        f"[{args.run_id}] train={len(train_ds)} val={len(val_ds)} "
        f"size={args.size} bs={args.batch_size} steps/epoch={len(train_loader)} "
        f"params={cfg['params']/1e6:.2f}M film={args.film} nwd={args.nwd} rfs={args.rfs}",
        flush=True,
    )

    param_groups = make_param_groups(
        model, base_lr=args.lr, backbone_mult=args.backbone_lr_mult, weight_decay=args.weight_decay
    )
    optimizer = torch.optim.AdamW(param_groups)
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer, lambda e: lr_lambda(e, args.warmup_epochs, args.epochs)
    )
    ema = None if args.no_ema else ModelEMA(model, decay=args.ema_decay, warmup=100)
    amp_dtype = {"bf16": torch.bfloat16, "fp16": torch.float16, "none": None}[args.amp]
    scaler = torch.amp.GradScaler("cuda", enabled=args.amp == "fp16")

    start_epoch = 0
    best = -1.0
    best_epoch = -1
    bad_epochs = 0
    history: list[dict] = []
    log_path = out_dir / "train_log.csv"
    log_fields = [
        "epoch", "time_s", "lr", "loss", "loss_vfl", "loss_bbox", "loss_giou",
        "mAP", "mAP50", "mAP75", "macro_AP", "tail_AP_2", "tail_AP_4", "eval_time_s",
    ]
    if args.resume and (out_dir / "last.pt").exists():
        ck = torch.load(out_dir / "last.pt", map_location="cpu", weights_only=False)
        model.load_state_dict(ck["model"])
        optimizer.load_state_dict(ck["optimizer"])
        scheduler.load_state_dict(ck["scheduler"])
        if ema is not None and ck.get("ema") is not None:
            ema.ema.load_state_dict(ck["ema"])
        start_epoch = ck["epoch"] + 1
        best = ck.get("best", -1.0)
        best_epoch = ck.get("best_epoch", -1)
        history = ck.get("history", [])
        print(f"[{args.run_id}] resumed at epoch {start_epoch} (best {best:.4f})", flush=True)

    writer = None
    try:
        from torch.utils.tensorboard import SummaryWriter

        writer = SummaryWriter(out_dir / "tb")
    except Exception:
        pass

    t_train_start = time.time()
    for epoch in range(start_epoch, args.epochs):
        model.train()
        t0 = time.time()
        sums = {"loss": 0.0, "loss_vfl": 0.0, "loss_bbox": 0.0, "loss_giou": 0.0}
        n_steps = 0
        for batch in train_loader:
            pixel_values = batch["pixel_values"].to(device, non_blocking=True)
            labels = [
                {"class_labels": l["class_labels"].to(device), "boxes": l["boxes"].to(device)}
                for l in batch["labels"]
            ]
            mag = batch["mag_ids"].to(device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast("cuda", dtype=amp_dtype, enabled=amp_dtype is not None):
                set_mag_ids(model, mag)
                out = model(pixel_values=pixel_values, labels=labels)
                loss = out.loss
            if scaler.is_enabled():
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
                scaler.step(optimizer)
                scaler.update()
            else:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
                optimizer.step()
            if ema is not None:
                ema.update(model)
            n_steps += 1
            sums["loss"] += float(loss.detach())
            for k in ("loss_vfl", "loss_bbox", "loss_giou"):
                if k in out.loss_dict:
                    sums[k] += float(out.loss_dict[k].detach())
        scheduler.step()
        train_time = time.time() - t0
        n = max(n_steps, 1)
        row = {"epoch": epoch, "time_s": train_time, "lr": optimizer.param_groups[0]["lr"]}
        row.update({k: v / n for k, v in sums.items()})

        if (epoch + 1) % args.val_interval == 0 or epoch == args.epochs - 1:
            t1 = time.time()
            if ema is not None:
                # Swap EMA weights into the model (which owns the FiLM hook),
                # evaluate, then restore the training weights.
                backup = {k: v.detach().clone() for k, v in model.state_dict().items()}
                model.load_state_dict(ema.state_dict())
                m = evaluate(model, val_ds, args, device)
                model.load_state_dict(backup)
            else:
                m = evaluate(model, val_ds, args, device)
            row.update(
                {
                    "mAP": m["mAP"],
                    "mAP50": m["mAP50"],
                    "mAP75": m["mAP75"],
                    "macro_AP": m["macro_AP"],
                    "tail_AP_2": m["tail_AP_2"],
                    "tail_AP_4": m["tail_AP_4"],
                    "eval_time_s": time.time() - t1,
                    "per_class_AP": m["per_class_AP"],
                }
            )
            score = m["mAP"]
            print(
                f"[{args.run_id}] ep{epoch} loss {row['loss']:.1f} "
                f"mAP {m['mAP']:.4f} mAP50 {m['mAP50']:.4f} macro {m['macro_AP']:.4f} "
                f"tail2 {m['tail_AP_2']:.4f} ({train_time:.0f}s/{time.time()-t1:.0f}s)",
                flush=True,
            )
            if score > best + 1e-5:
                best, best_epoch, bad_epochs = score, epoch, 0
                torch.save(
                    {"model": (ema.state_dict() if ema is not None else model.state_dict()), "config": cfg, "epoch": epoch, "metrics": m},
                    out_dir / "best.pt",
                )
            else:
                bad_epochs += 1
        else:
            print(f"[{args.run_id}] ep{epoch} loss {row['loss']:.1f} ({train_time:.0f}s)", flush=True)

        history.append(row)
        if writer is not None:
            for k, v in row.items():
                if isinstance(v, (int, float)):
                    writer.add_scalar(k, v, epoch)
        if epoch == start_epoch:
            with log_path.open("w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=log_fields, extrasaction="ignore")
                w.writeheader()
        with log_path.open("a", newline="") as f:
            csv.DictWriter(f, fieldnames=log_fields, extrasaction="ignore").writerow(row)

        torch.save(
            {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(),
                "ema": ema.state_dict() if ema is not None else None,
                "epoch": epoch,
                "best": best,
                "best_epoch": best_epoch,
                "history": history,
                "config": cfg,
            },
            out_dir / "last.pt",
        )

        if args.patience > 0 and bad_epochs >= args.patience:
            print(f"[{args.run_id}] early stop at epoch {epoch} (best {best:.4f} @ {best_epoch})", flush=True)
            break

    # final evaluation with the best checkpoint, full + tiled
    ann_test = args.ann_test or args.ann_val
    test_ds = AlgaeDataset(ann_test, args.img_root, size=args.size, train=False)
    final = {
        "best_mAP": best,
        "best_epoch": best_epoch,
        "train_time_s": time.time() - t_train_start,
        "ann_test": ann_test,
    }
    if (out_dir / "best.pt").exists():
        ck = torch.load(out_dir / "best.pt", map_location="cpu", weights_only=False)
        model.load_state_dict(ck["model"])
    model.eval()
    for mode in ("full", "tile"):
        m = evaluate(model, test_ds, args, device, tiling=(mode == "tile"), groups=True, ann_file=ann_test)
        final[f"test_{mode}"] = m
        print(f"[{args.run_id}] final {mode}: mAP {m['mAP']:.4f} mAP50 {m['mAP50']:.4f} macro {m['macro_AP']:.4f}", flush=True)

    # inference speed (batch 1, full image)
    if torch.cuda.is_available():
        x = torch.randn(1, 3, args.size, args.size, device=device)
        with torch.no_grad(), torch.autocast("cuda", dtype=amp_dtype, enabled=amp_dtype is not None):
            for _ in range(10):
                set_mag_ids(model, torch.zeros(1, dtype=torch.long, device=device))
                model(pixel_values=x)
            torch.cuda.synchronize()
            t = time.time()
            for _ in range(50):
                set_mag_ids(model, torch.zeros(1, dtype=torch.long, device=device))
                model(pixel_values=x)
            torch.cuda.synchronize()
        final["fps_batch1"] = 50 / (time.time() - t)
    final["params"] = cfg["params"]
    final["config"] = cfg
    (out_dir / "metrics.json").write_text(json.dumps(final, indent=1, default=float))
    print(f"[{args.run_id}] done. best mAP={best:.4f} @ep{best_epoch}", flush=True)


if __name__ == "__main__":
    main()
