"""Normalised Wasserstein Distance (NWD) box regression loss.

Small objects have unstable IoU because a one-pixel shift can halve the
overlap.  NWD models a box as a 2-D Gaussian and compares means/covariances,
which is smooth at small scales.  We use a hybrid

    L_reg = (1 - GIoU) + lambda * (1 - NWD)

so large objects keep the well-behaved GIoU signal while tiny cells get a
dense, scale-aware gradient.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F
from transformers.loss.loss_d_fine import DFineLoss
from transformers.loss.loss_for_object_detection import generalized_box_iou
from transformers.image_transforms import center_to_corners_format

_NWD_WEIGHT = 0.5
_NWD_C = 0.05


def set_nwd(weight: float = 0.5, c: float = 0.05) -> None:
    global _NWD_WEIGHT, _NWD_C
    _NWD_WEIGHT = float(weight)
    _NWD_C = float(c)


def nwd_distance(src_cxcywh: torch.Tensor, tgt_cxcywh: torch.Tensor, c: float | None = None) -> torch.Tensor:
    """Return NWD similarity in [0, 1] for normalised cxcywh boxes."""
    c = _NWD_C if c is None else c
    dx = src_cxcywh[:, 0] - tgt_cxcywh[:, 0]
    dy = src_cxcywh[:, 1] - tgt_cxcywh[:, 1]
    dw = src_cxcywh[:, 2] - tgt_cxcywh[:, 2]
    dh = src_cxcywh[:, 3] - tgt_cxcywh[:, 3]
    w2 = dx * dx + dy * dy + 0.25 * (dw * dw + dh * dh)
    return torch.exp(-torch.sqrt(w2.clamp_min(1e-12)) / c)


def loss_boxes_nwd(self, outputs, targets, indices, num_boxes):
    if "pred_boxes" not in outputs:
        raise KeyError("No predicted boxes found in outputs")
    idx = self._get_source_permutation_idx(indices)
    src_boxes = outputs["pred_boxes"][idx]
    target_boxes = torch.cat([t["boxes"][i] for t, (_, i) in zip(targets, indices)], dim=0)
    if src_boxes.numel() == 0:
        zero = src_boxes.sum() * 0.0
        return {"loss_bbox": zero, "loss_giou": zero}

    losses = {}
    loss_bbox = F.l1_loss(src_boxes, target_boxes, reduction="none")
    losses["loss_bbox"] = loss_bbox.sum() / num_boxes

    giou = torch.diag(
        generalized_box_iou(center_to_corners_format(src_boxes), center_to_corners_format(target_boxes))
    )
    nwd = nwd_distance(src_boxes, target_boxes)
    loss_reg = (1.0 - giou) + _NWD_WEIGHT * (1.0 - nwd)
    losses["loss_giou"] = loss_reg.sum() / num_boxes
    return losses


def enable_nwd(weight: float = 0.5, c: float = 0.05) -> None:
    set_nwd(weight, c)
    DFineLoss.loss_boxes = loss_boxes_nwd
