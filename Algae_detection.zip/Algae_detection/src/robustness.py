"""Robustness evaluation under synthetic image degradations.

For each (degradation, severity) pair the validation images are written to a
temporary directory, the detector is run on them, and COCO AP is computed.
The clean baseline is included as severity 0.
"""
from __future__ import annotations

import argparse
import io
import json
import shutil
import sys
import tempfile
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image, ImageEnhance, ImageFilter

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.dataset import AlgaeDataset
from src.evaluate import coco_metrics, group_metrics, load_checkpoint, predict_dataset

LEVELS: dict[str, list[float]] = {
    "clean": [0.0],
    "gaussian_blur": [0.5, 1.0, 2.0, 3.0],
    "motion_blur": [3, 7, 15],
    "gaussian_noise": [5, 10, 20, 40],
    "brightness": [-0.4, -0.2, 0.2, 0.4],
    "contrast": [-0.4, -0.2, 0.2, 0.4],
    "jpeg": [90, 70, 50, 30],
    "color_temp": [-0.4, -0.2, 0.2, 0.4],
    "occlusion": [0.1, 0.3, 0.5],
}


def degrade(img: Image.Image, kind: str, level: float, seed: int = 0) -> Image.Image:
    rng = np.random.default_rng(seed)
    if kind == "clean":
        return img
    if kind == "gaussian_blur":
        return img.filter(ImageFilter.GaussianBlur(radius=float(level)))
    if kind == "motion_blur":
        k = int(level)
        kernel = np.zeros((k, k), np.float32)
        kernel[k // 2, :] = 1.0 / k
        arr = cv2.filter2D(np.asarray(img), -1, kernel)
        return Image.fromarray(arr)
    if kind == "gaussian_noise":
        arr = np.asarray(img).astype(np.float32) + rng.normal(0, level, (img.height, img.width, 3))
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
    if kind == "brightness":
        return ImageEnhance.Brightness(img).enhance(max(0.05, 1 + level))
    if kind == "contrast":
        return ImageEnhance.Contrast(img).enhance(max(0.05, 1 + level))
    if kind == "jpeg":
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=int(level))
        buf.seek(0)
        return Image.open(buf).convert("RGB")
    if kind == "color_temp":
        arr = np.asarray(img).astype(np.float32)
        arr[..., 0] *= 1 + level  # R
        arr[..., 2] *= 1 - level  # B
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
    if kind == "occlusion":
        arr = np.asarray(img).copy()
        h, w = arr.shape[:2]
        target = int(level * h * w)
        done = 0
        while done < target:
            bw = int(rng.integers(w // 12, w // 4))
            bh = int(rng.integers(h // 12, h // 4))
            x = int(rng.integers(0, max(w - bw, 1)))
            y = int(rng.integers(0, max(h - bh, 1)))
            arr[y : y + bh, x : x + bw] = 0
            done += bw * bh
        return Image.fromarray(arr)
    raise ValueError(kind)


def make_condition_dir(ann: dict, img_root: Path, out: Path, kind: str, level: float, seed: int = 0) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    (out / "imgs").mkdir(exist_ok=True)
    new = json.loads(json.dumps(ann))
    for im in new["images"]:
        src = img_root / im["file_name"]
        dst = out / "imgs" / f"{im['id']:05d}.jpg"
        if kind == "clean":
            shutil.copy(src, dst)
        else:
            with Image.open(src) as img:
                img = degrade(img.convert("RGB"), kind, level, seed=seed + im["id"])
                img.save(dst, quality=95)
        im["file_name"] = f"imgs/{im['id']:05d}.jpg"
    (out / "ann.json").write_text(json.dumps(new))
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--ann", default="data/coco/annotations/instances_val.json")
    ap.add_argument("--img-root", default="algae")
    ap.add_argument("--out", default="results/robustness.json")
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--tiling", action="store_true")
    ap.add_argument("--tile-size", type=int, default=None)
    ap.add_argument("--tile-aspect", type=float, default=2.0)
    ap.add_argument("--overlap", type=float, default=0.25)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--levels", default=None, help="comma-separated degradation names")
    args = ap.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    model, cfg = load_checkpoint(args.ckpt, device)
    size = cfg.get("size", 1280)
    ann = json.loads(Path(args.ann).read_text())
    img_root = Path(args.img_root)
    kinds = (args.levels.split(",") if args.levels else list(LEVELS))
    tmp_root = Path(tempfile.mkdtemp(prefix="algae_robust_"))
    rows = []
    try:
        for kind in kinds:
            for level in LEVELS[kind]:
                cdir = make_condition_dir(ann, img_root, tmp_root / f"{kind}_{level}", kind, level, seed=1234)
                ds = AlgaeDataset(str(cdir / "ann.json"), str(cdir), size=size, train=False)
                preds, info = predict_dataset(
                    model, ds, device, batch_size=args.batch_size,
                    tiling=args.tiling, tile_size=args.tile_size, overlap=args.overlap, tile_aspect=args.tile_aspect,
                )
                m = coco_metrics(str(cdir / "ann.json"), preds)
                g = group_metrics(str(cdir / "ann.json"), preds)
                row = {
                    "model": args.name,
                    "degradation": kind,
                    "level": level,
                    "mAP": m["mAP"],
                    "mAP50": m["mAP50"],
                    "mAP75": m["mAP75"],
                    "macro_AP": m["macro_AP"],
                    "per_class_AP": m["per_class_AP"],
                    "per_group": {k: v["mAP"] for k, v in g.items()},
                    "fps": info["fps"],
                }
                rows.append(row)
                print(json.dumps(row), flush=True)
                shutil.rmtree(cdir, ignore_errors=True)
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rows, indent=1))
    print(f"wrote {len(rows)} rows to {out}")


if __name__ == "__main__":
    main()
