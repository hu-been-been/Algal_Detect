"""Per-image counts from COCO detections, for counting/ecology figures."""
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import pandas as pd


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--preds", required=True)
    ap.add_argument("--ann", required=True)
    ap.add_argument("--thr", type=float, default=0.3)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    ann = json.loads(Path(args.ann).read_text())
    preds = json.loads(Path(args.preds).read_text())
    gt_by_img: dict[int, list[int]] = defaultdict(list)
    for a in ann["annotations"]:
        gt_by_img[a["image_id"]].append(a["category_id"])
    pr_by_img: dict[int, list[int]] = defaultdict(list)
    for r in preds:
        if r["score"] >= args.thr:
            pr_by_img[r["image_id"]].append(r["category_id"])

    rows = []
    for im in ann["images"]:
        g = gt_by_img.get(im["id"], [])
        p = pr_by_img.get(im["id"], [])
        row = {
            "image_id": im["id"],
            "file_name": im["file_name"],
            "width": im["width"],
            "height": im["height"],
            "group": "A" if im["width"] / max(im["height"], 1) > 2.2 else (
                "B" if im["width"] * im["height"] < 520_000 else "C"),
            "gt": len(g),
            "pred": len(p),
        }
        for c in range(6):
            row[f"gt_c{c}"] = sum(1 for v in g if v == c)
            row[f"pred_c{c}"] = sum(1 for v in p if v == c)
        rows.append(row)
    df = pd.DataFrame(rows)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out, index=False)
    print(df[["gt", "pred"]].describe().to_string())
    print(f"wrote {len(df)} rows to {args.out}")


if __name__ == "__main__":
    main()
