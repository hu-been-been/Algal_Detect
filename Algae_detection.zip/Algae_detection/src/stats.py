"""Statistical comparison of runs (paired folds, bootstrap CIs, Wilcoxon)."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


def bootstrap_ci(x: np.ndarray, n: int = 10000, seed: int = 0) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), (n, len(x)))
    means = x[idx].mean(1)
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def paired(a: np.ndarray, b: np.ndarray) -> dict:
    d = a - b
    lo, hi = bootstrap_ci(d)
    out = {"n": int(len(d)), "mean_diff": float(d.mean()), "ci95": [lo, hi]}
    if len(d) >= 6 and np.any(d != 0):
        try:
            w = stats.wilcoxon(a, b, zero_method="wilcox", alternative="two-sided")
            out["wilcoxon_p"] = float(w.pvalue)
        except ValueError:
            out["wilcoxon_p"] = None
        t = stats.ttest_rel(a, b)
        out["ttest_p"] = float(t.pvalue)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="results/all_runs.csv")
    ap.add_argument("--out", default="results/stats.json")
    args = ap.parse_args()
    df = pd.read_csv(args.runs)
    out: dict = {}

    # five-fold: base vs full, paired by fold and seed
    folds = df[df["run_id"].str.startswith("fold") & df["mAP_full"].notna()].copy()
    if not folds.empty:
        folds["variant"] = np.where(
            folds["run_id"].str.contains(r"final|full", regex=True), "final", "base")
        folds["fold"] = folds["run_id"].str.extract(r"fold(\d)")[0].astype(int)
        piv = folds.pivot_table(index=["fold", "seed"], columns="variant", values="mAP_full")
        if {"base", "final"}.issubset(piv.columns):
            piv = piv.dropna(subset=["base", "final"])
            out["folds"] = {
                "base_mean": float(piv["base"].mean()),
                "final_mean": float(piv["final"].mean()),
                "paired": paired(piv["final"].to_numpy(), piv["base"].to_numpy()),
            }
        # Friedman across the main variants when available
        variants = folds.groupby("variant")["mAP_full"].apply(list)
        if len(variants) >= 3:
            try:
                stat, p = stats.friedmanchisquare(*[v for v in variants if len(v) >= 5])
                out["folds"]["friedman"] = {"stat": float(stat), "p": float(p)}
            except Exception:
                pass

    # ablation: paired by seed against the base variant
    mods = pd.concat([
        df[df["run_id"].str.startswith("mod_")],
        df[df["run_id"].str.startswith("bench")
           & (df["family"] == "dfine") & (df["size"] == 1280)],
    ])
    mods = mods[mods["mAP_full"].notna()].copy()
    if not mods.empty:
        mods["variant"] = (
            np.where(mods["film"], "F", "")
            + np.where(mods["nwd"], "N", "")
            + np.where(mods["rfs"], "R", "")
            + np.where(mods["copy_paste"] > 0, "C", "")
        )
        mods.loc[mods["variant"] == "", "variant"] = "base"
        mods = mods[mods["tile_train"]]
        base = mods[mods["variant"] == "base"].set_index("seed")["mAP_full"]
        res = {}
        for v, sub in mods.groupby("variant"):
            if v == "base":
                continue
            s = sub.set_index("seed")["mAP_full"]
            common = base.index.intersection(s.index)
            if len(common) >= 2:
                res[v] = paired(s.loc[common].to_numpy(), base.loc[common].to_numpy())
                res[v]["mean"] = float(s.mean())
        out["ablation"] = res

    # benchmark: mean and bootstrap CI per family × size
    bench = df[df["run_id"].str.startswith("bench") & df["mAP_full"].notna()].copy()
    if not bench.empty:
        rows = {}
        for (fam, size), sub in bench.groupby(["family", "size"]):
            key = f"{fam}_{int(size)}" if not pd.isna(size) else str(fam)
            lo, hi = bootstrap_ci(sub["mAP_full"].to_numpy())
            rows[key] = {"mean": float(sub["mAP_full"].mean()),
                         "std": float(sub["mAP_full"].std()),
                         "ci95": [lo, hi], "n": int(len(sub))}
        out["benchmark"] = rows

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(out, indent=1))
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
