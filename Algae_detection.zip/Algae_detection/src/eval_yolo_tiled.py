"""Tiled inference for an Ultralytics YOLO checkpoint (fair comparison).

Uses the same adaptive tiling policy as the D-FINE evaluator: 2:1 tiles for
wide strips, square 800 px tiles for large frames, whole image otherwise.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image
from ultralytics import YOLO

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.evaluate import coco_metrics, group_metrics, results_from_arrays, tile_grid


def default_short_side(w: int, h: int) -> tuple[int, float | None]:
    if w / max(h, 1) > 2.2:
        return min(h, 800), 2.0
    if w * h > 1_500_000:
        return 800, None
    return max(w, h), None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", required=True)
    ap.add_argument("--ann", default="data/coco/annotations/instances_val.json")
    ap.add_argument("--img-root", default="algae")
    ap.add_argument("--imgsz", type=int, default=1280)
    ap.add_argument("--overlap", type=float, default=0.25)
    ap.add_argument("--conf", type=float, default=0.001)
    ap.add_argument("--nms-iou", type=float, default=0.6)
    ap.add_argument("--no-tiling", action="store_true",
                    help="evaluate the whole image, matching Ultralytics val")
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="0")
    args = ap.parse_args()

    model = YOLO(args.weights)
    ann = json.loads(Path(args.ann).read_text())
    img_root = Path(args.img_root)
    results = []
    t0 = time.time()
    n_tiles = 0
    for im in ann["images"]:
        img = Image.open(img_root / im["file_name"]).convert("RGB")
        w, h = img.size
        if args.no_tiling:
            boxes = [(0, 0, w, h)]
        else:
            short, aspect = default_short_side(w, h)
            if short >= max(w, h) * 0.95:
                boxes = [(0, 0, w, h)]
            else:
                boxes = tile_grid(w, h, int(short), args.overlap, aspect=aspect)
        n_tiles += len(boxes)
        crops = [np.asarray(img.crop(b))[..., ::-1] for b in boxes]  # RGB -> BGR
        preds = model.predict(crops, imgsz=args.imgsz, conf=args.conf, iou=0.7,
                              verbose=False, device=args.device)
        all_xyxy, all_scores, all_labels = [], [], []
        for b, r in zip(boxes, preds):
            if r.boxes is None or len(r.boxes) == 0:
                continue
            xyxy = r.boxes.xyxy.cpu().numpy()
            xyxy[:, [0, 2]] += b[0]
            xyxy[:, [1, 3]] += b[1]
            all_xyxy.append(xyxy)
            all_scores.append(r.boxes.conf.cpu().numpy())
            all_labels.append(r.boxes.cls.cpu().numpy().astype(np.int64))
        if not all_xyxy:
            continue
        xyxy = np.concatenate(all_xyxy)
        scores = np.concatenate(all_scores)
        labels = np.concatenate(all_labels)
        # NMS across tiles, per class, in original coordinates
        results.extend(results_from_arrays(im["id"], xyxy, scores, labels, args.nms_iou, 300))

    elapsed = time.time() - t0
    m = coco_metrics(args.ann, results)
    m["per_group"] = group_metrics(args.ann, results)
    m["inference"] = {"fps": len(ann["images"]) / elapsed, "n_tiles": n_tiles,
                      "sec_per_image": elapsed / len(ann["images"])}
    m["weights"] = args.weights
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(m, indent=1, default=float))
    (out.parent / (out.stem + "_preds.json")).write_text(json.dumps(results))
    print(json.dumps({k: v for k, v in m.items() if k not in ("per_class_AP", "per_class_AP50")}, indent=1))
    print("per class:", m["per_class_AP"])


if __name__ == "__main__":
    main()
