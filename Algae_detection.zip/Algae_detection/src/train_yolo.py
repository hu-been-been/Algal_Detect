"""Ultralytics YOLO baseline with augmentations matched to the D-FINE runs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ultralytics import YOLO


def resolve_model(name: str) -> str:
    p = Path(name)
    if p.exists():
        return str(p)
    root = Path(__file__).resolve().parents[1]
    for d in (root / "weights", root):
        q = d / name
        if q.exists():
            return str(q)
    return name


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="yolo11s.pt")
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--data", default="data/yolo/data.yaml")
    ap.add_argument("--size", type=int, default=1280)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", default="0")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--project", default="runs_yolo")
    ap.add_argument("--patience", type=int, default=30)
    ap.add_argument("--lr0", type=float, default=0.001)
    ap.add_argument("--fraction", type=float, default=1.0)
    ap.add_argument("--no-train", action="store_true")
    ap.add_argument("--weights", default=None, help="checkpoint for validation-only")
    args = ap.parse_args()

    model = YOLO(resolve_model(args.weights or args.model))
    # Ultralytics prepends runs/detect/ to a relative project, so resolve it
    # once and use the same absolute path for training and for loading back.
    project = Path(args.project).resolve()
    if not args.no_train:
        model.train(
            data=args.data,
            imgsz=args.size,
            epochs=args.epochs,
            batch=args.batch,
            device=args.device,
            workers=args.workers,
            project=str(project),
            name=args.run_id,
            exist_ok=True,
            seed=args.seed,
            deterministic=True,
            pretrained=True,
            optimizer="AdamW",
            lr0=args.lr0,
            lrf=0.01,
            warmup_epochs=5,
            cos_lr=True,
            weight_decay=0.0005,
            patience=args.patience,
            amp=True,
            fraction=args.fraction,
            cache=False,
            plots=False,
            save=True,
            val=True,
            verbose=True,
            # microscopy-friendly augmentation: no mosaic / mixup / hue shifts
            mosaic=0.0,
            close_mosaic=0,
            mixup=0.0,
            copy_paste=0.0,
            erasing=0.0,
            hsv_h=0.0,
            hsv_s=0.2,
            hsv_v=0.2,
            degrees=0.0,
            translate=0.1,
            scale=0.2,
            shear=0.0,
            perspective=0.0,
            flipud=0.5,
            fliplr=0.5,
        )

    if args.no_train and args.weights:
        best = Path(resolve_model(args.weights))
    else:
        best = project / args.run_id / "weights" / "best.pt"
        if not best.exists():
            best = project / args.run_id / "weights" / "last.pt"
    m = YOLO(str(best))
    val = m.val(data=args.data, imgsz=args.size, batch=args.batch, device=args.device, plots=False, verbose=True)
    out = {
        "run_id": args.run_id,
        "model": args.model,
        "size": args.size,
        "seed": args.seed,
        "epochs": args.epochs,
        "mAP": float(val.box.map),
        "mAP50": float(val.box.map50),
        "mAP75": float(val.box.map75),
        "per_class_AP": {str(i): float(v) for i, v in enumerate(val.box.maps)},
        "precision": float(val.box.mp),
        "recall": float(val.box.mr),
        "params": sum(p.numel() for p in m.model.parameters()),
        "speed_ms": val.speed,
    }
    dest = project / args.run_id / "metrics.json"
    dest.write_text(json.dumps(out, indent=1, default=float))
    print(json.dumps(out, indent=1, default=float))


if __name__ == "__main__":
    main()
