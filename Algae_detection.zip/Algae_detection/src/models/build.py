"""Model construction: D-FINE with optional magnification-conditioned FiLM."""
from __future__ import annotations

import glob
from pathlib import Path
from typing import Iterable

import torch
import torch.nn as nn
from transformers import (
    DFineConfig,
    DFineForObjectDetection,
    RTDetrV2Config,
    RTDetrV2ForObjectDetection,
)

from src.data.dataset import CLASS_NAMES


class MagFiLM(nn.Module):
    """Feature-wise linear modulation conditioned on the acquisition scale.

    One embedding per magnification bucket, a small MLP per backbone level
    producing (gamma, beta).  The last layer is zero-initialised so that the
    module starts as an identity transform and fine-tuning is stable.
    """

    def __init__(self, num_mags: int, channels: Iterable[int], hidden: int = 128):
        super().__init__()
        self.num_mags = num_mags
        self.channels = list(channels)
        self.embed = nn.Embedding(num_mags, hidden)
        nn.init.normal_(self.embed.weight, std=0.02)
        self.mlps = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(hidden, hidden),
                    nn.SiLU(),
                    nn.Linear(hidden, 2 * c),
                )
                for c in self.channels
            ]
        )
        for mlp in self.mlps:
            nn.init.zeros_(mlp[-1].weight)
            nn.init.zeros_(mlp[-1].bias)

    def forward(self, feats: list[torch.Tensor], mag_ids: torch.Tensor) -> list[torch.Tensor]:
        if mag_ids.device != feats[0].device:
            mag_ids = mag_ids.to(feats[0].device)
        emb = self.embed(mag_ids)  # [B, hidden]
        out = []
        for f, mlp in zip(feats, self.mlps):
            gb = mlp(emb)
            gamma, beta = gb.chunk(2, dim=-1)
            gamma = gamma.view(-1, self.channels[len(out)], 1, 1)
            beta = beta.view(-1, self.channels[len(out)], 1, 1)
            out.append(f * (1.0 + gamma) + beta)
        return out


def attach_film(model: DFineForObjectDetection, num_mags: int = 3, hidden: int = 128) -> MagFiLM:
    """Attach FiLM to the backbone output via a forward hook.

    The hook reads ``model._mag_ids`` which the training / inference loop sets
    before every forward pass.
    """
    channels = model.model.backbone.intermediate_channel_sizes
    film = MagFiLM(num_mags=num_mags, channels=channels, hidden=hidden)
    model.film = film
    model._mag_ids = None

    def hook(module, args, output):
        mag_ids = getattr(model, "_mag_ids", None)
        if mag_ids is None:
            return output
        output.feature_maps = film(list(output.feature_maps), mag_ids)
        return output

    model.model.backbone.model.register_forward_hook(hook)
    return film


def resolve_ckpt(ckpt: str | None) -> str:
    if ckpt:
        p = Path(ckpt)
        if p.is_dir():
            snaps = sorted(glob.glob(str(p / "snapshots" / "*")))
            if snaps:
                return snaps[-1]
        return str(p)
    # Hugging Face model id; transformers downloads and caches it on first use.
    return "ustc-community/dfine-small-obj365"


def resolve_rtdetr_ckpt(ckpt: str | None) -> str:
    if ckpt:
        return resolve_ckpt(ckpt)
    # Hugging Face model id; transformers downloads and caches it on first use.
    return "PekingU/rtdetr_v2_r50vd"


def build_model(
    ckpt: str | None = None,
    num_classes: int = 6,
    film: bool = False,
    num_mags: int = 3,
    film_hidden: int = 128,
    arch: str = "dfine",
    denoising: bool = True,
    head_prior: list[float] | None = None,
) -> torch.nn.Module:
    if arch == "dfine":
        ckpt = resolve_ckpt(ckpt)
        config = DFineConfig.from_pretrained(ckpt)
    elif arch == "rtdetr":
        ckpt = resolve_rtdetr_ckpt(ckpt)
        config = RTDetrV2Config.from_pretrained(ckpt)
    else:
        raise ValueError(f"unknown arch {arch}")
    config.num_labels = num_classes
    config.id2label = {i: n for i, n in enumerate(CLASS_NAMES[:num_classes])}
    config.label2id = {n: i for i, n in enumerate(CLASS_NAMES[:num_classes])}
    if not denoising:
        config.num_denoising = 0
    cls = DFineForObjectDetection if arch == "dfine" else RTDetrV2ForObjectDetection
    model = cls.from_pretrained(ckpt, config=config, ignore_mismatched_sizes=True)
    if head_prior:
        # Initialise the reinitialised class heads to the class priors instead
        # of a flat 0.5, which matters for strongly imbalanced label sets.
        import torch as _torch

        p = _torch.tensor(head_prior, dtype=_torch.float32).clamp(1e-4, 1 - 1e-4)
        bias = -_torch.log((1 - p) / p)
        heads = []
        dec = getattr(model.model, "decoder", None)
        if dec is not None and hasattr(dec, "class_embed"):
            heads += list(dec.class_embed)
        enc = getattr(model.model, "enc_score_head", None)
        if enc is not None:
            heads.append(enc)
        with _torch.no_grad():
            for h in heads:
                if getattr(h, "bias", None) is not None and h.bias.numel() == num_classes:
                    h.bias.copy_(bias)
    if film:
        if arch != "dfine":
            raise ValueError("FiLM is only implemented for D-FINE")
        attach_film(model, num_mags=num_mags, hidden=film_hidden)
    return model


def set_mag_ids(model: nn.Module, mag_ids: torch.Tensor) -> None:
    model._mag_ids = mag_ids


def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def make_param_groups(
    model: nn.Module,
    base_lr: float,
    backbone_mult: float = 0.1,
    weight_decay: float = 1e-4,
) -> list[dict]:
    """Backbone at a lower LR, everything else at base LR; no WD on norm/bias."""
    backbone_names = set()
    for n, _ in model.named_parameters():
        if n.startswith("model.backbone."):
            backbone_names.add(n)

    groups: dict[tuple[str, bool], list[nn.Parameter]] = {}
    for n, p in model.named_parameters():
        if not p.requires_grad:
            continue
        is_backbone = n in backbone_names
        no_decay = p.ndim <= 1 or n.endswith(".bias")
        key = ("backbone" if is_backbone else "head", no_decay)
        groups.setdefault(key, []).append(p)

    out = []
    for (part, no_decay), params in groups.items():
        lr = base_lr * backbone_mult if part == "backbone" else base_lr
        out.append(
            {
                "params": params,
                "lr": lr,
                "weight_decay": 0.0 if no_decay else weight_decay,
                "name": f"{part}_{'nodecay' if no_decay else 'decay'}",
            }
        )
    return out


class ModelEMA:
    def __init__(self, model: nn.Module, decay: float = 0.999, warmup: int = 100):
        import copy

        self.ema = copy.deepcopy(model).eval()
        for p in self.ema.parameters():
            p.requires_grad_(False)
        self.decay = decay
        self.warmup = warmup
        self.updates = 0

    @torch.no_grad()
    def update(self, model: nn.Module) -> None:
        self.updates += 1
        d = self.decay * (1 - torch.exp(torch.tensor(-self.updates / max(self.warmup, 1)))).item()
        msd = model.state_dict()
        for k, v in self.ema.state_dict().items():
            if v.dtype.is_floating_point:
                v.mul_(d).add_(msd[k].detach().to(v.device), alpha=1 - d)
            else:
                v.copy_(msd[k])

    def state_dict(self):
        return self.ema.state_dict()
